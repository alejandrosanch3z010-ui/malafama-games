<?php
$titulo = 'Catálogo';
require 'includes/header.php';

$f = [
    'q'          => trim($_GET['q'] ?? ''),
    'genero'     => $_GET['genero'] ?? '',
    'formato'    => $_GET['formato'] ?? '',
    'precio_max' => $_GET['precio_max'] ?? '',
    'cal_min'    => $_GET['cal_min'] ?? '',
    'estado'     => $_GET['estado'] ?? '',
    'orden'      => $_GET['orden'] ?? 'novedades',
];
$generos = db()->query('SELECT * FROM generos WHERE activo = 1 ORDER BY nombre')->fetchAll();
$scriptsExtra = ['js/catalogo.js?v=1'];

// Marca como seleccionada la opción que coincide con el filtro actual
function sel($actual, $valor) { return (string)$actual === (string)$valor ? 'selected' : ''; }
function chk($actual, $valor) { return (string)$actual === (string)$valor ? 'checked' : ''; }
?>

<div class="contenedor catalogo">
    <div class="catalogo-cabecera">
        <h1>Catálogo</h1>
        <p id="conteo" aria-live="polite">Cargando…</p>
        <button class="btn btn-secundario filtros-btn" id="filtros-btn" aria-controls="filtros" aria-expanded="false">Filtros</button>
    </div>

    <form class="filtros" id="filtros" method="get" data-js="catalogo">
        <label>Buscar
            <input type="search" name="q" value="<?= e($f['q']) ?>" placeholder="Título o desarrollador" autocomplete="off">
        </label>

        <label>Ordenar por
            <select name="orden">
                <option value="novedades" <?= sel($f['orden'], 'novedades') ?>>Más recientes</option>
                <option value="calificacion" <?= sel($f['orden'], 'calificacion') ?>>Mejor calificados</option>
                <option value="precio_asc" <?= sel($f['orden'], 'precio_asc') ?>>Precio: menor a mayor</option>
                <option value="precio_desc" <?= sel($f['orden'], 'precio_desc') ?>>Precio: mayor a menor</option>
                <option value="titulo" <?= sel($f['orden'], 'titulo') ?>>Nombre (A-Z)</option>
            </select>
        </label>

        <fieldset>
            <legend>Mostrar</legend>
            <label class="opcion"><input type="radio" name="estado" value="" <?= chk($f['estado'], '') ?>> Todos</label>
            <label class="opcion"><input type="radio" name="estado" value="novedades" <?= chk($f['estado'], 'novedades') ?>> Novedades</label>
            <label class="opcion"><input type="radio" name="estado" value="preventa" <?= chk($f['estado'], 'preventa') ?>> Preventas</label>
            <label class="opcion"><input type="radio" name="estado" value="ofertas" <?= chk($f['estado'], 'ofertas') ?>> Ofertas</label>
        </fieldset>

        <label>Género
            <select name="genero">
                <option value="">Todos</option>
                <?php foreach ($generos as $g): ?>
                    <option value="<?= $g['id'] ?>" <?= sel($f['genero'], $g['id']) ?>><?= e($g['nombre']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <fieldset>
            <legend>Formato</legend>
            <label class="opcion"><input type="radio" name="formato" value="" <?= chk($f['formato'], '') ?>> Ambos</label>
            <label class="opcion"><input type="radio" name="formato" value="fisico" <?= chk($f['formato'], 'fisico') ?>> Físico</label>
            <label class="opcion"><input type="radio" name="formato" value="digital" <?= chk($f['formato'], 'digital') ?>> Digital</label>
        </fieldset>

        <label>Precio máximo
            <select name="precio_max">
                <option value="">Sin límite</option>
                <?php foreach ([500, 800, 1000, 1300, 1600] as $p): ?>
                    <option value="<?= $p ?>" <?= sel($f['precio_max'], $p) ?>>Hasta <?= dinero($p) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label>Calificación
            <select name="cal_min">
                <option value="">Cualquiera</option>
                <option value="4.5" <?= sel($f['cal_min'], '4.5') ?>>★ 4.5 o más</option>
                <option value="4" <?= sel($f['cal_min'], '4') ?>>★ 4 o más</option>
            </select>
        </label>

        <div class="filtros-acciones">
            <button class="btn" type="submit">Aplicar</button>
            <a class="btn btn-secundario" href="catalogo.php">Limpiar</a>
        </div>
    </form>

    <section class="resultados" aria-live="polite">
        <div class="rejilla" id="rejilla"></div>
        <div class="estado-carga" id="estado-carga" hidden></div>
        <nav class="paginacion" id="paginacion" aria-label="Páginas"></nav>
        <noscript><p class="sin-contenido">Activa JavaScript para ver el catálogo.</p></noscript>
    </section>
</div>

<?php require 'includes/footer.php'; ?>

<?php
require_once 'includes/funciones.php';

// Los juegos dados de baja solo los ve el personal
$st = db()->prepare('SELECT j.*, g.nombre AS genero FROM juegos j JOIN generos g ON g.id = j.genero_id WHERE j.slug = ?' . (puede('juegos.gestionar') ? '' : ' AND j.activo = 1'));
$st->execute([$_GET['j'] ?? '']);
$juego = $st->fetch();

if (!$juego) {
    http_response_code(404);
    $titulo = 'Juego no encontrado';
    require 'includes/header.php';
    echo '<div class="contenedor vacio"><h1>Juego no encontrado</h1><p>Puede que ya no esté en el catálogo.</p><a class="btn" href="catalogo.php">Ir al catálogo</a></div>';
    require 'includes/footer.php';
    exit;
}

$st = db()->prepare("SELECT * FROM ediciones WHERE juego_id = ? ORDER BY version <> 'Estándar', version, formato = 'digital'");
$st->execute([$juego['id']]);
$ediciones = $st->fetchAll();

$st = db()->prepare('SELECT * FROM capturas WHERE juego_id = ? ORDER BY orden');
$st->execute([$juego['id']]);
$capturas = $st->fetchAll();

$relacionados = array_filter(
    buscarJuegos(['genero' => $juego['genero_id'], 'orden' => 'calificacion'], 5),
    fn($r) => $r['id'] != $juego['id']
);

$u = usuarioActual();
$guardado = $u && enDeseos($u['id'], $juego['id']);

// Reseñas: distribución de estrellas, lista y la del propio cliente
$st = db()->prepare('SELECT calificacion, COUNT(*) AS n FROM resenas WHERE juego_id = ? GROUP BY calificacion');
$st->execute([$juego['id']]);
$distribucion = array_fill(1, 5, 0);
foreach ($st->fetchAll() as $fila) $distribucion[$fila['calificacion']] = (int)$fila['n'];

$st = db()->prepare('SELECT r.*, u.nombre FROM resenas r JOIN usuarios u ON u.id = r.usuario_id WHERE r.juego_id = ? ORDER BY r.creado DESC LIMIT 30');
$st->execute([$juego['id']]);
$resenas = $st->fetchAll();

$miResena = null;
if ($u) {
    $st = db()->prepare('SELECT * FROM resenas WHERE juego_id = ? AND usuario_id = ?');
    $st->execute([$juego['id'], $u['id']]);
    $miResena = $st->fetch();
}

$preventa = esPreventa($juego['fecha_lanzamiento']);
$titulo = $juego['titulo'];
require 'includes/header.php';
?>

<div class="contenedor ficha">
    <nav class="migas"><a href="catalogo.php">Catálogo</a> › <a href="catalogo.php?genero=<?= $juego['genero_id'] ?>"><?= e($juego['genero']) ?></a></nav>

    <div class="ficha-principal">
        <div class="ficha-portada"><?= portada($juego, '', 'vertical') ?></div>

        <div class="ficha-compra">
            <span class="tarjeta-genero"><?= e($juego['genero']) ?> · <?= e($juego['desarrollador']) ?></span>
            <h1><?= e($juego['titulo']) ?></h1>

            <?php if ($juego['total_resenas'] > 0): ?>
                <p class="ficha-cal"><span class="estrellas"><?= estrellas($juego['calificacion']) ?></span> <?= $juego['calificacion'] ?> · <a href="#resenas"><?= $juego['total_resenas'] ?> <?= $juego['total_resenas'] == 1 ? 'reseña' : 'reseñas' ?></a></p>
            <?php endif; ?>

            <?php if ($preventa): ?>
                <div class="aviso-preventa">
                    <p>Preventa · Sale el <?= fechaLarga($juego['fecha_lanzamiento']) ?></p>
                    <div class="contador grande" data-fecha="<?= e($juego['fecha_lanzamiento']) ?>"></div>
                </div>
            <?php endif; ?>

            <form class="ediciones" id="form-compra" method="post" action="carrito-accion.php" data-api="carrito" data-metodo="POST" data-exito="aviso">
                <?= campoCsrf() ?>
                <input type="hidden" name="accion" value="agregar">
                <input type="hidden" name="volver" value="juego.php?j=<?= e(urlencode($juego['slug'])) ?>">
                <?php $versiones = [];
                foreach ($ediciones as $ed) $versiones[$ed['version']][] = $ed; ?>
                <p class="subtitulo"><?= count($versiones) > 1 ? 'Elige la versión y el formato' : 'Elige el formato' ?></p>
                <?php $marcado = false; // se marca la primera edición que sí tenga existencias
                foreach ($versiones as $version => $opciones): ?>
                    <div class="version">
                        <?php if (count($versiones) > 1): ?>
                            <p class="version-nombre"><?= e($version) ?><?php if ($version === 'Estándar'): ?> <small>Solo el juego</small><?php endif; ?></p>
                            <?php if ($opciones[0]['incluye']): ?><p class="version-incluye"><?= e($opciones[0]['incluye']) ?></p><?php endif; ?>
                        <?php endif; ?>
                        <?php foreach ($opciones as $ed):
                            $estado = estadoStock($juego['fecha_lanzamiento'], $ed['stock']);
                            $agotado = $estado['clase'] === 'agotado'; ?>
                            <label class="edicion <?= $agotado ? 'deshabilitada' : '' ?>">
                                <input type="radio" name="edicion" value="<?= $ed['id'] ?>" <?= $agotado ? 'disabled' : '' ?> <?php if (!$agotado && !$marcado) { echo 'checked'; $marcado = true; } ?>>
                                <span class="edicion-nombre"><?= nombreFormato($ed['formato']) ?></span>
                                <span class="insignia <?= $estado['clase'] ?>"><?= $estado['texto'] ?></span>
                                <span class="edicion-precio">
                                    <?php if ($ed['precio_oferta']): ?><del><?= dinero($ed['precio']) ?></del><?php endif; ?>
                                    <strong><?= dinero($ed['precio_oferta'] ?: $ed['precio']) ?></strong>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>

                <?php if ($marcado): ?>
                    <div class="botones-compra">
                        <button class="btn btn-grande" type="submit" name="comprar_ya" value="1"><?= $preventa ? 'Apartar en preventa' : 'Comprar ahora' ?></button>
                        <button class="btn btn-grande btn-secundario" type="submit">Agregar al carrito</button>
                    </div>
                <?php else: ?>
                    <button class="btn btn-grande" type="button" disabled>Agotado</button>
                <?php endif; ?>
                <p class="nota-segura">🔒 Pago seguro con tarjeta, PayPal, Mercado Pago u OXXO Pay</p>
            </form>

            <form method="post" action="deseos-accion.php" class="form-deseo" data-api="<?= $guardado ? 'deseos/' . $juego['id'] : 'deseos' ?>" data-metodo="<?= $guardado ? 'DELETE' : 'POST' ?>">
                <?= campoCsrf() ?>
                <input type="hidden" name="juego_id" value="<?= $juego['id'] ?>">
                <input type="hidden" name="volver" value="juego.php?j=<?= e(urlencode($juego['slug'])) ?>">
                <button class="btn-deseo <?= $guardado ? 'guardado' : '' ?>" type="submit" aria-pressed="<?= $guardado ? 'true' : 'false' ?>">
                    <span aria-hidden="true"><?= $guardado ? '♥' : '♡' ?></span>
                    <?= $guardado ? 'En tu lista de deseos' : 'Agregar a mi lista de deseos' ?>
                </button>
            </form>
        </div>
    </div>

    <section class="ficha-bloque">
        <h2>Tráiler</h2>
        <?php if ($juego['trailer_youtube']): ?>
            <div class="video">
                <iframe src="https://www.youtube-nocookie.com/embed/<?= e($juego['trailer_youtube']) ?>" title="Tráiler de <?= e($juego['titulo']) ?>" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" allowfullscreen loading="lazy"></iframe>
            </div>
        <?php else: ?>
            <p class="sin-contenido">Tráiler no disponible por el momento.</p>
        <?php endif; ?>
    </section>

    <?php if ($capturas): ?>
    <section class="ficha-bloque">
        <h2>Capturas</h2>
        <div class="capturas">
            <?php foreach ($capturas as $c): ?>
                <img src="<?= e($c['ruta']) ?>" alt="Captura de <?= e($juego['titulo']) ?>" loading="lazy">
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <div class="ficha-columnas">
        <section class="ficha-bloque">
            <h2>Sinopsis</h2>
            <p><?= e($juego['sinopsis']) ?></p>
        </section>

        <section class="ficha-bloque">
            <h2>Detalles</h2>
            <dl class="detalles">
                <dt>Lanzamiento</dt><dd><?= fechaLarga($juego['fecha_lanzamiento']) ?></dd>
                <dt>Desarrollador</dt><dd><?= e($juego['desarrollador']) ?></dd>
                <dt>Clasificación</dt><dd><?= e($juego['clasificacion']) ?></dd>
                <dt>Voces</dt><dd><?= e($juego['voces']) ?></dd>
                <dt>Subtítulos</dt><dd><?= e($juego['subtitulos']) ?></dd>
                <dt>Internet</dt>
                <dd>
                    <?= $juego['requiere_internet'] ? '<strong class="rojo">Requiere conexión</strong>' : 'No requiere para jugar' ?>
                    <?php if ($juego['nota_internet']): ?><br><small><?= e($juego['nota_internet']) ?></small><?php endif; ?>
                </dd>
            </dl>
        </section>
    </div>

    <section class="ficha-bloque resenas-sec" id="resenas">
        <h2>Reseñas de clientes</h2>
        <div class="resenas-grid">
            <div>
                <div class="resumen-cal">
                    <b><?= $juego['total_resenas'] ? $juego['calificacion'] : '–' ?></b>
                    <div>
                        <span class="estrellas"><?= estrellas($juego['calificacion']) ?></span>
                        <small><?= $juego['total_resenas'] ?> <?= $juego['total_resenas'] == 1 ? 'reseña' : 'reseñas' ?></small>
                    </div>
                </div>
                <?php $total = max(1, array_sum($distribucion)); ?>
                <ul class="barras">
                    <?php for ($i = 5; $i >= 1; $i--): ?>
                        <li><span><?= $i ?> ★</span><i><em style="width:<?= round($distribucion[$i] * 100 / $total) ?>%"></em></i><span><?= $distribucion[$i] ?></span></li>
                    <?php endfor; ?>
                </ul>

                <div class="caja-form">
                    <?php if ($preventa): ?>
                        <p>Podrás dejar tu reseña cuando el juego salga a la venta.</p>
                    <?php elseif ($u): ?>
                        <h3><?= $miResena ? 'Edita tu reseña' : 'Escribe tu reseña' ?></h3>
                        <form method="post" action="resena.php" data-api="juegos/<?= $juego['id'] ?>/resenas" data-metodo="POST">
                            <?= campoCsrf() ?>
                            <input type="hidden" name="juego_id" value="<?= $juego['id'] ?>">
                            <?= selectorEstrellas($miResena['calificacion'] ?? 0) ?>
                            <label>Comentario (opcional)
                                <textarea name="comentario" rows="4" maxlength="1000" placeholder="¿Qué te pareció el juego?"><?= e($miResena['comentario'] ?? '') ?></textarea>
                            </label>
                            <button class="btn" type="submit"><?= $miResena ? 'Actualizar reseña' : 'Publicar reseña' ?></button>
                        </form>
                    <?php else: ?>
                        <p>Inicia sesión para calificar este juego.</p>
                        <a class="btn" href="login.php?volver=<?= urlencode('juego.php?j=' . $juego['slug'] . '#resenas') ?>">Iniciar sesión</a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="lista-resenas">
                <?php foreach ($resenas as $r) echo tarjetaResena($r); ?>
                <?php if (!$resenas): ?><p class="sin-contenido">Todavía no hay reseñas de este juego.</p><?php endif; ?>
            </div>
        </div>
    </section>

    <?= filaJuegos('También te puede gustar', array_values($relacionados)) ?>
</div>

<?php require 'includes/footer.php'; ?>

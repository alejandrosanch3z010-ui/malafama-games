<?php
require_once 'includes/funciones.php';
$u = usuarioActual();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verificarCsrf();
    requiereLogin();
    $cal = (int)($_POST['calificacion'] ?? 0);
    $comentario = trim($_POST['comentario'] ?? '');
    if ($cal < 1 || $cal > 5 || mb_strlen($comentario) > 1000) {
        flash('Elige de 1 a 5 estrellas y escribe hasta 1000 caracteres.', 'error');
    } else {
        // Una opinión por cliente: si ya dejó una, se actualiza
        $st = db()->prepare('SELECT id FROM resenas_tienda WHERE usuario_id = ?');
        $st->execute([$u['id']]);
        if ($id = $st->fetchColumn()) {
            db()->prepare('UPDATE resenas_tienda SET calificacion = ?, comentario = ?, creado = NOW() WHERE id = ?')
                ->execute([$cal, $comentario ?: null, $id]);
        } else {
            db()->prepare('INSERT INTO resenas_tienda (usuario_id, calificacion, comentario) VALUES (?, ?, ?)')
                ->execute([$u['id'], $cal, $comentario ?: null]);
        }
        flash('¡Gracias por tu opinión sobre la tienda!');
    }
    redirigir('opiniones.php');
}

$resumen = db()->query('SELECT COUNT(*) AS total, ROUND(AVG(calificacion), 1) AS promedio FROM resenas_tienda')->fetch();
$opiniones = db()->query('SELECT r.*, u.nombre FROM resenas_tienda r JOIN usuarios u ON u.id = r.usuario_id ORDER BY r.creado DESC LIMIT 50')->fetchAll();
$mia = null;
if ($u) {
    $st = db()->prepare('SELECT * FROM resenas_tienda WHERE usuario_id = ?');
    $st->execute([$u['id']]);
    $mia = $st->fetch();
}

$titulo = 'Opiniones de la tienda';
require 'includes/header.php';
?>
<div class="contenedor pagina">
    <div class="pagina-cabecera">
        <?= letreroNeon('Opiniones', 'amarillo') ?>
        <?php if ($resumen['total']): ?>
            <p class="resumen-grande"><span class="estrellas"><?= estrellas($resumen['promedio']) ?></span>
                <b><?= $resumen['promedio'] ?></b> de 5 · <?= $resumen['total'] ?> opiniones de clientes</p>
        <?php endif; ?>
    </div>

    <div class="opiniones-grid">
        <section class="caja-form">
            <h2><?= $mia ? 'Edita tu opinión' : '¿Qué tal tu experiencia?' ?></h2>
            <?php if ($u): ?>
                <form method="post">
                    <?= campoCsrf() ?>
                    <?= selectorEstrellas($mia['calificacion'] ?? 0) ?>
                    <label>Comentario (opcional)
                        <textarea name="comentario" rows="4" maxlength="1000" placeholder="Cuéntanos sobre tu compra, el envío o la atención…"><?= e($mia['comentario'] ?? '') ?></textarea>
                    </label>
                    <button class="btn" type="submit"><?= $mia ? 'Actualizar opinión' : 'Publicar opinión' ?></button>
                </form>
            <?php else: ?>
                <p>Inicia sesión para opinar sobre la tienda.</p>
                <a class="btn" href="login.php?volver=opiniones.php">Iniciar sesión</a>
            <?php endif; ?>
        </section>

        <section class="lista-resenas">
            <?php foreach ($opiniones as $o) echo tarjetaResena($o); ?>
            <?php if (!$opiniones): ?><p class="sin-contenido">Todavía no hay opiniones. ¡Sé el primero!</p><?php endif; ?>
        </section>
    </div>
</div>
<?php require 'includes/footer.php'; ?>

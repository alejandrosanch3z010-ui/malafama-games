<?php
// Guarda (o actualiza) la reseña del cliente para un juego
require_once 'includes/funciones.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirigir('index.php');
verificarCsrf();
requiereLogin();
$u = usuarioActual();

$st = db()->prepare('SELECT id, slug FROM juegos WHERE id = ?');
$st->execute([(int)($_POST['juego_id'] ?? 0)]);
$juego = $st->fetch();
if (!$juego) redirigir('catalogo.php');

$volver = 'juego.php?j=' . urlencode($juego['slug']) . '#resenas';
$cal = (int)($_POST['calificacion'] ?? 0);
$comentario = trim($_POST['comentario'] ?? '');

if ($cal < 1 || $cal > 5) {
    flash('Elige de 1 a 5 estrellas.', 'error');
    redirigir($volver);
}
if (mb_strlen($comentario) > 1000) {
    flash('Tu comentario puede tener hasta 1000 caracteres.', 'error');
    redirigir($volver);
}

// Una reseña por cliente y juego: si ya existe, se actualiza
$st = db()->prepare('INSERT INTO resenas (juego_id, usuario_id, calificacion, comentario) VALUES (?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE calificacion = VALUES(calificacion), comentario = VALUES(comentario), creado = NOW()');
$st->execute([$juego['id'], $u['id'], $cal, $comentario !== '' ? $comentario : null]);
actualizarCalificacion($juego['id']);

flash('¡Gracias por tu reseña!');
redirigir($volver);

<?php
require_once 'includes/funciones.php';
$tarjetas = db()->query('SELECT * FROM tarjetas_psn ORDER BY monto')->fetchAll();

$titulo = 'Tarjetas PSN';
require 'includes/header.php';
?>
<div class="contenedor pagina">
    <div class="pagina-cabecera">
        <?= letreroNeon('Tarjetas PSN', 'cian') ?>
        <p>Saldo para la PlayStation Store. Recibes el código al instante después de pagar.</p>
    </div>
    <div class="tarjetas-psn">
        <?php foreach ($tarjetas as $t): ?>
            <form class="psn" method="post" action="carrito-accion.php" data-api="carrito" data-metodo="POST" data-exito="aviso">
                <?= campoCsrf() ?>
                <input type="hidden" name="accion" value="agregar">
                <input type="hidden" name="tarjeta" value="<?= $t['id'] ?>">
                <input type="hidden" name="volver" value="tarjetas-psn.php">
                <div class="psn-arte">
                    <span class="ps5">PSN</span>
                    <b><?= dinero($t['monto']) ?></b>
                    <small>MXN · Saldo PlayStation Store</small>
                </div>
                <p class="psn-precio"><?= dinero($t['precio']) ?> MXN</p>
                <button class="btn" type="submit" <?= $t['stock'] > 0 ? '' : 'disabled' ?>><?= $t['stock'] > 0 ? 'Agregar al carrito' : 'Agotada' ?></button>
            </form>
        <?php endforeach; ?>
    </div>
    <p class="ayuda-pago">Canjea el código en tu PS5 en PlayStation Store → ··· → Canjear código. (Tienda escolar: los códigos son de demostración).</p>
</div>
<?php require 'includes/footer.php'; ?>

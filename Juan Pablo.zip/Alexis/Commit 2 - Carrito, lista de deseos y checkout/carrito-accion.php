<?php
// Agregar, cambiar cantidad, quitar o vaciar el carrito
require_once 'includes/funciones.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirigir('carrito.php');
verificarCsrf();

$accion = $_POST['accion'] ?? '';
$volver = volverSeguro($_POST['volver'] ?? '', 'carrito.php');
$c = carrito();

// Clave del producto: edición de juego (e) o tarjeta PSN (t)
$clave = '';
if (!empty($_POST['edicion'])) $clave = 'e' . (int)$_POST['edicion'];
if (!empty($_POST['tarjeta'])) $clave = 't' . (int)$_POST['tarjeta'];
if (!empty($_POST['clave']) && preg_match('/^[et]\d+$/', $_POST['clave'])) $clave = $_POST['clave'];

// Existencias actuales del producto
function existencias($clave) {
    $id = (int)substr($clave, 1);
    $sql = $clave[0] === 'e' ? 'SELECT stock FROM ediciones WHERE id = ?' : 'SELECT stock FROM tarjetas_psn WHERE id = ?';
    $st = db()->prepare($sql);
    $st->execute([$id]);
    $v = $st->fetchColumn();
    return $v === false ? null : (int)$v;
}

if ($accion === 'vaciar') {
    guardarCarrito([]);
    flash('Vaciaste tu carrito.', 'info');
    redirigir('carrito.php');
}

if ($clave === '' || ($stock = existencias($clave)) === null) {
    flash('Elige un formato disponible.', 'error');
    redirigir($volver);
}

if ($accion === 'quitar') {
    unset($c[$clave]);
    guardarCarrito($c);
    flash('Quitaste el producto del carrito.', 'info');
    redirigir('carrito.php');
}

$limite = min(MAX_POR_PRODUCTO, $stock);
if ($limite <= 0) {
    flash('Ese producto está agotado.', 'error');
    redirigir($volver);
}

if ($accion === 'agregar') {
    $nueva = ($c[$clave] ?? 0) + max(1, (int)($_POST['cantidad'] ?? 1));
    $c[$clave] = min($nueva, $limite);
    guardarCarrito($c);
    flash($nueva > $limite ? "Solo puedes llevar $limite de este producto." : 'Se agregó a tu carrito.', $nueva > $limite ? 'info' : 'ok');
    redirigir(isset($_POST['comprar_ya']) ? 'carrito.php' : $volver);
}

if ($accion === 'cantidad') {
    $cant = (int)($_POST['cantidad'] ?? 1);
    if ($cant <= 0) unset($c[$clave]); else $c[$clave] = min($cant, $limite);
    guardarCarrito($c);
    redirigir('carrito.php');
}

redirigir('carrito.php');

<?php
require_once 'includes/funciones.php';
$items = carritoItems();
$u = usuarioActual();
$tot = carritoTotales($items);

$titulo = 'Carrito';
require 'includes/header.php';
?>
<div class="contenedor pagina">
    <div class="pagina-cabecera">
        <?= letreroNeon('Carrito', 'cian') ?>
        <p><?= piezasEnCarrito() ?> <?= piezasEnCarrito() === 1 ? 'producto' : 'productos' ?></p>
    </div>

    <?php if (!$items): ?>
        <div class="vacio">
            <h2>Tu carrito está vacío</h2>
            <p>Agrega juegos desde su ficha o revisa las ofertas.</p>
            <a class="btn" href="catalogo.php">Explorar juegos</a>
        </div>
    <?php else: ?>
    <div class="compra-grid">
        <section class="lista-carrito" aria-label="Productos">
            <?php foreach ($items as $it): ?>
                <article class="item-carrito">
                    <a href="<?= e($it['url']) ?>" class="item-arte">
                        <?= $it['arte'] ? portada($it['arte']) : '<div class="portada tarjeta-psn-mini"><b>PSN</b><span>' . dinero($it['monto']) . '</span></div>' ?>
                    </a>
                    <div class="item-info">
                        <a href="<?= e($it['url']) ?>"><h3><?= e($it['titulo']) ?></h3></a>
                        <p><?= e($it['detalle']) ?><?= $it['digital'] ? ' · Recibes el código al pagar' : '' ?></p>
                        <?php if ($it['stock'] < $it['cantidad']): ?><p class="error-campo">Solo quedan <?= $it['stock'] ?> piezas.</p><?php endif; ?>
                        <div class="item-acciones">
                            <form method="post" action="carrito-accion.php" class="form-cantidad" data-api="carrito/<?= e($it['clave']) ?>" data-metodo="PATCH">
                                <?= campoCsrf() ?>
                                <input type="hidden" name="accion" value="cantidad">
                                <input type="hidden" name="clave" value="<?= e($it['clave']) ?>">
                                <label>Cantidad
                                    <select name="cantidad" onchange="this.form.requestSubmit()">
                                        <?php for ($i = 1; $i <= max(1, min(MAX_POR_PRODUCTO, $it['stock'])); $i++): ?>
                                            <option value="<?= $i ?>" <?= $i == $it['cantidad'] ? 'selected' : '' ?>><?= $i ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </label>
                                <noscript><button class="btn-quitar" type="submit">Actualizar</button></noscript>
                            </form>
                            <form method="post" action="carrito-accion.php" data-api="carrito/<?= e($it['clave']) ?>" data-metodo="DELETE" data-confirmar="¿Quitar <?= e($it['titulo']) ?> del carrito?">
                                <?= campoCsrf() ?>
                                <input type="hidden" name="accion" value="quitar">
                                <input type="hidden" name="clave" value="<?= e($it['clave']) ?>">
                                <button class="btn-quitar" type="submit">Quitar</button>
                            </form>
                        </div>
                    </div>
                    <p class="item-precio">
                        <strong><?= dinero($it['precio'] * $it['cantidad']) ?></strong>
                        <?php if ($it['precio_normal'] > $it['precio']): ?><del><?= dinero($it['precio_normal'] * $it['cantidad']) ?></del><?php endif; ?>
                    </p>
                </article>
            <?php endforeach; ?>

            <form method="post" action="carrito-accion.php" data-api="carrito" data-metodo="DELETE" data-confirmar="¿Seguro que quieres vaciar todo el carrito?">
                <?= campoCsrf() ?>
                <input type="hidden" name="accion" value="vaciar">
                <button class="btn-quitar" type="submit">Vaciar carrito</button>
            </form>
        </section>

        <aside class="resumen">
            <h2>Resumen</h2>
            <dl>
                <dt>Subtotal</dt><dd><?= dinero($tot['subtotal']) ?></dd>
                <dt>Envío</dt><dd><?= $tot['hay_fisico'] ? 'Gratis' : 'No aplica (todo es digital)' ?></dd>
                <dt class="total">Total</dt><dd class="total"><?= dinero($tot['total']) ?> MXN</dd>
            </dl>
            <p class="puntos-aviso">★ Con esta compra ganas <b><?= $tot['puntos_ganados'] ?> puntos</b> (<?= dinero($tot['puntos_ganados'] * VALOR_PUNTO) ?> de descuento en tu próxima compra).</p>
            <?php if ($u && $u['puntos'] > 0): ?>
                <p class="puntos-aviso">Tienes <b><?= $u['puntos'] ?> puntos</b>: los puedes usar en el pago.</p>
            <?php endif; ?>
            <a class="btn btn-grande" href="checkout.php"><?= $u ? 'Continuar al pago' : 'Inicia sesión para pagar' ?></a>
            <p class="nota-segura">🔒 Tarjeta, PayPal, Mercado Pago u OXXO Pay</p>
        </aside>
    </div>
    <?php endif; ?>
</div>
<?php require 'includes/footer.php'; ?>

<?php
require_once 'includes/funciones.php';
requiereLogin();
$u = usuarioActual();
$items = carritoItems();
if (!$items) redirigir('carrito.php');

$st = db()->prepare('SELECT telefono, direccion FROM usuarios WHERE id = ?');
$st->execute([$u['id']]);
$perfil = $st->fetch();

$d = [
    'metodo' => 'tarjeta', 'usar_puntos' => false,
    'recibe' => $u['nombre'], 'telefono' => $perfil['telefono'] ?? '', 'direccion' => $perfil['direccion'] ?? '',
    'cp' => '', 'ciudad' => '', 'estado' => '',
];
$errores = [];
$tot = carritoTotales($items);

// Respaldo sin JavaScript: la venta la hace la misma función del backend que usa la API (POST /api/pedidos)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verificarCsrf();
    foreach (['recibe', 'telefono', 'direccion', 'cp', 'ciudad', 'estado', 'metodo'] as $k) $d[$k] = trim($_POST[$k] ?? '');
    $d['usar_puntos'] = !empty($_POST['usar_puntos']);
    $tot = carritoTotales($items, $d['usar_puntos'], $u['puntos']);
    try {
        $pedidoId = crearPedido($u, $_POST);
        flash('¡Pago aprobado! Tu pedido está confirmado.');
        redirigir('pedido.php?id=' . $pedidoId . '&nuevo=1');
    } catch (ErrorNegocio $ex) {
        $errores = $ex->campos ?: ['pago' => $ex->getMessage()];
        if (!isset($errores['pago']) && $ex->status !== 422) $errores['pago'] = $ex->getMessage();
    }
}

function err($errores, $k) { return isset($errores[$k]) ? '<small class="error-campo">' . e($errores[$k]) . '</small>' : ''; }

$titulo = 'Pagar';
require 'includes/header.php';
?>
<div class="contenedor pagina">
    <div class="pagina-cabecera"><?= letreroNeon('Pago', 'morado') ?></div>
    <?php if (isset($errores['pago'])): ?><p class="alerta" role="alert"><?= e($errores['pago']) ?></p><?php endif; ?>

    <form method="post" class="compra-grid" novalidate data-api="pedidos" data-metodo="POST" data-confirmar="¿Confirmas el pago de tu pedido?">
        <?= campoCsrf() ?>
        <div class="pasos">
            <?php if ($tot['hay_fisico']): ?>
            <section class="caja-form">
                <h2>1. Dirección de envío</h2>
                <div class="campos-2">
                    <label>¿Quién recibe?<input type="text" name="recibe" value="<?= e($d['recibe']) ?>" autocomplete="name"><?= err($errores, 'recibe') ?></label>
                    <label>Teléfono<input type="text" name="telefono" value="<?= e($d['telefono']) ?>" inputmode="numeric" autocomplete="tel"><?= err($errores, 'telefono') ?></label>
                </div>
                <label>Calle, número y colonia<input type="text" name="direccion" value="<?= e($d['direccion']) ?>" autocomplete="street-address"><?= err($errores, 'direccion') ?></label>
                <div class="campos-3">
                    <label>C.P.<input type="text" name="cp" value="<?= e($d['cp']) ?>" inputmode="numeric" maxlength="5" autocomplete="postal-code"><?= err($errores, 'cp') ?></label>
                    <label>Ciudad<input type="text" name="ciudad" value="<?= e($d['ciudad']) ?>" autocomplete="address-level2"><?= err($errores, 'ciudad') ?></label>
                    <label>Estado<input type="text" name="estado" value="<?= e($d['estado']) ?>" autocomplete="address-level1"><?= err($errores, 'estado') ?></label>
                </div>
                <label class="check"><input type="checkbox" name="guardar_direccion" value="1" checked> Guardar esta dirección para mis próximas compras</label>
            </section>
            <?php endif; ?>

            <section class="caja-form">
                <h2><?= $tot['hay_fisico'] ? '2.' : '1.' ?> Método de pago</h2>
                <?= err($errores, 'metodo') ?>
                <div class="metodos-pago">
                    <?php foreach (['tarjeta' => '💳', 'paypal' => '🅿️', 'mercadopago' => '🤝', 'oxxo' => '🏪'] as $m => $icono): ?>
                        <label class="metodo">
                            <input type="radio" name="metodo" value="<?= $m ?>" <?= $d['metodo'] === $m ? 'checked' : '' ?>>
                            <span aria-hidden="true"><?= $icono ?></span> <?= nombreMetodo($m) ?>
                        </label>
                    <?php endforeach; ?>
                </div>

                <div class="panel-metodo" data-metodo="tarjeta">
                    <label>Número de tarjeta<input type="text" name="tarjeta_numero" inputmode="numeric" autocomplete="cc-number" placeholder="4242 4242 4242 4242" maxlength="19"><?= err($errores, 'tarjeta_numero') ?></label>
                    <label>Nombre en la tarjeta<input type="text" name="tarjeta_nombre" autocomplete="cc-name"><?= err($errores, 'tarjeta_nombre') ?></label>
                    <div class="campos-2">
                        <label>Vence (MM/AA)<input type="text" name="tarjeta_venc" placeholder="08/29" autocomplete="cc-exp" maxlength="5"><?= err($errores, 'tarjeta_venc') ?></label>
                        <label>CVV<input type="password" name="tarjeta_cvv" inputmode="numeric" autocomplete="cc-csc" maxlength="4"><?= err($errores, 'tarjeta_cvv') ?></label>
                    </div>
                    <p class="ayuda-pago">Pago simulado: usa cualquier número de 16 dígitos. Si termina en <b>0002</b>, el banco lo rechaza para probar un error. No se guarda ningún dato de la tarjeta.</p>
                </div>
                <div class="panel-metodo" data-metodo="paypal"><p class="ayuda-pago">Pago simulado: al confirmar se aprueba como si hubieras entrado a tu cuenta de PayPal.</p></div>
                <div class="panel-metodo" data-metodo="mercadopago"><p class="ayuda-pago">Pago simulado: al confirmar se aprueba como si hubieras pagado en Mercado Pago.</p></div>
                <div class="panel-metodo" data-metodo="oxxo"><p class="ayuda-pago">Recibirás una referencia para pagar en cualquier OXXO. En esta demostración el pago se marca como recibido al instante.</p></div>
            </section>
        </div>

        <aside class="resumen">
            <h2>Tu pedido</h2>
            <ul class="resumen-items">
                <?php foreach ($items as $it): ?>
                    <li><span><?= $it['cantidad'] ?> × <?= e($it['titulo']) ?><small><?= e($it['detalle']) ?></small></span><b><?= dinero($it['precio'] * $it['cantidad']) ?></b></li>
                <?php endforeach; ?>
            </ul>
            <?php $max = carritoTotales($items, true, $u['puntos'])['puntos_usados']; ?>
            <?php if ($max > 0): ?>
                <label class="check usar-puntos">
                    <input type="checkbox" name="usar_puntos" value="1" <?= $d['usar_puntos'] ? 'checked' : '' ?> data-descuento="<?= $max * VALOR_PUNTO ?>">
                    Usar <?= $max ?> de mis <?= $u['puntos'] ?> puntos (−<?= dinero($max * VALOR_PUNTO) ?>)
                </label>
            <?php endif; ?>
            <dl>
                <dt>Subtotal</dt><dd><?= dinero($tot['subtotal']) ?></dd>
                <dt>Puntos</dt><dd id="linea-puntos">−<?= dinero($tot['descuento']) ?></dd>
                <dt class="total">Total</dt><dd class="total" id="total-pagar" data-subtotal="<?= $tot['subtotal'] ?>"><?= dinero($tot['total']) ?> MXN</dd>
                <dt class="iva">IVA incluido (<?= IVA * 100 ?>%)</dt><dd class="iva" id="iva-pagar"><?= dinero($tot['total'] - $tot['total'] / (1 + IVA)) ?></dd>
            </dl>
            <p class="puntos-aviso">★ Ganarás <b><?= $tot['puntos_ganados'] ?> puntos</b> con esta compra.</p>
            <label class="check acepto">
                <input type="checkbox" name="acepto" value="1" <?= !empty($_POST['acepto']) ? 'checked' : '' ?> required>
                <span>Acepto los <a href="terminos.php" target="_blank">Términos</a> y la <a href="devoluciones.php" target="_blank">Política de Devoluciones</a>. Entiendo que los códigos digitales no son reembolsables una vez entregados.</span>
            </label>
            <?= err($errores, 'acepto') ?>
            <button class="btn btn-grande" type="submit">Pagar ahora</button>
            <p class="nota-segura">🔒 Pagos simulados para fines escolares: no se guarda ningún dato de tu tarjeta · <a href="privacidad.php" target="_blank">Aviso de Privacidad</a></p>
        </aside>
    </form>
</div>
<?php require 'includes/footer.php'; ?>

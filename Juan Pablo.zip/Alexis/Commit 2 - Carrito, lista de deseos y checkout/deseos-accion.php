<?php
// Agrega o quita un juego de la lista de deseos
require_once 'includes/funciones.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirigir('index.php');
verificarCsrf();

$volver = volverSeguro($_POST['volver'] ?? '');
$u = usuarioActual();
if (!$u) {
    flash('Inicia sesión para guardar juegos en tu lista de deseos.', 'info');
    redirigir('login.php?volver=' . urlencode($volver));
}

$st = db()->prepare('SELECT id, titulo FROM juegos WHERE id = ?');
$st->execute([(int)($_POST['juego_id'] ?? 0)]);
$juego = $st->fetch();

if ($juego) {
    if (enDeseos($u['id'], $juego['id'])) {
        db()->prepare('DELETE FROM wishlist WHERE usuario_id = ? AND juego_id = ?')->execute([$u['id'], $juego['id']]);
        flash($juego['titulo'] . ' salió de tu lista de deseos.', 'info');
    } else {
        db()->prepare('INSERT INTO wishlist (usuario_id, juego_id) VALUES (?, ?)')->execute([$u['id'], $juego['id']]);
        flash($juego['titulo'] . ' se guardó en tu lista de deseos. ♥');
    }
}
redirigir($volver);

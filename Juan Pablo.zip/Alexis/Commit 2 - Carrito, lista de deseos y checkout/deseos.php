<?php
require_once 'includes/funciones.php';
requiereLogin();
$u = usuarioActual();
$juegos = buscarJuegos(['deseos_de' => $u['id'], 'orden' => $_GET['orden'] ?? 'novedades']);
$enOferta = count(array_filter($juegos, fn($j) => $j['en_oferta']));

$titulo = 'Mi lista de deseos';
require 'includes/header.php';
?>
<div class="contenedor pagina">
    <div class="pagina-cabecera">
        <?= letreroNeon('Mis deseos', 'rosa') ?>
        <p><?= count($juegos) ?> <?= count($juegos) === 1 ? 'juego guardado' : 'juegos guardados' ?>
            <?php if ($enOferta): ?> · <strong class="texto-oferta"><?= $enOferta ?> con descuento ahora mismo</strong><?php endif; ?></p>
    </div>

    <?php if ($juegos): ?>
        <div class="rejilla">
            <?php foreach ($juegos as $j): ?>
                <div class="deseo">
                    <?= tarjetaJuego($j) ?>
                    <form method="post" action="deseos-accion.php" data-api="deseos/<?= $j['id'] ?>" data-metodo="DELETE">
                        <?= campoCsrf() ?>
                        <input type="hidden" name="juego_id" value="<?= $j['id'] ?>">
                        <input type="hidden" name="volver" value="deseos.php">
                        <button class="btn-quitar" type="submit">Quitar de la lista</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="vacio">
            <h2>Tu lista está vacía</h2>
            <p>Dale al corazón en la ficha de cualquier juego para guardarlo y ver si baja de precio.</p>
            <a class="btn" href="catalogo.php">Explorar juegos</a>
        </div>
    <?php endif; ?>
</div>
<?php require 'includes/footer.php'; ?>

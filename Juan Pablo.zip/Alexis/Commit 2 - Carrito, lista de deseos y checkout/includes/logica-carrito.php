<?php
// Carrito guardado en la sesión:  'e12' => 1  (edición 12, una pieza)  ·  't3' => 2  (tarjeta PSN 3, dos piezas)
// Los precios NO se guardan: siempre se vuelven a leer de la base para que no se puedan alterar.

const MAX_POR_PRODUCTO = 5;
const PUNTOS_POR_PESO = 0.05;   // se gana el 5% del precio de cada juego en puntos
const VALOR_PUNTO = 1.00;       // cada punto vale $1 de descuento
const MAX_DESCUENTO_PUNTOS = 0.5; // con puntos se paga como máximo la mitad del subtotal
const IVA = 0.16;               // los precios ya incluyen IVA; se desglosa en el pedido
const STOCK_BAJO = 5;           // alerta de existencias bajas

function carrito() {
    return $_SESSION['carrito'] ?? [];
}

function guardarCarrito($c) {
    abrirSesion();
    $_SESSION['carrito'] = $c;
}

function piezasEnCarrito() {
    return array_sum(carrito());
}

// Productos del carrito con sus datos actuales de la base
function carritoItems() {
    $items = [];
    foreach (carrito() as $clave => $cant) {
        $id = (int)substr($clave, 1);
        if ($clave[0] === 'e') {
            $st = db()->prepare('SELECT e.id, e.formato, e.version, e.stock, COALESCE(e.precio_oferta, e.precio) AS precio, e.precio AS precio_normal,
                                        j.id AS juego_id, j.titulo, j.slug, j.portada, j.fecha_lanzamiento
                                 FROM ediciones e JOIN juegos j ON j.id = e.juego_id WHERE e.id = ?');
            $st->execute([$id]);
            if (!$p = $st->fetch()) continue;
            $items[] = [
                'clave' => $clave, 'tipo' => 'juego', 'cantidad' => $cant, 'stock' => (int)$p['stock'],
                'precio' => (float)$p['precio'], 'precio_normal' => (float)$p['precio_normal'],
                'titulo' => $p['titulo'], 'detalle' => nombreEdicion($p) . (esPreventa($p['fecha_lanzamiento']) ? ' · Preventa' : ''),
                'digital' => $p['formato'] === 'digital', 'url' => 'juego.php?j=' . urlencode($p['slug']),
                'arte' => ['id' => $p['juego_id'], 'titulo' => $p['titulo'], 'portada' => $p['portada']],
                'edicion_id' => $p['id'], 'tarjeta_id' => null,
            ];
        } else {
            $st = db()->prepare('SELECT * FROM tarjetas_psn WHERE id = ?');
            $st->execute([$id]);
            if (!$t = $st->fetch()) continue;
            $items[] = [
                'clave' => $clave, 'tipo' => 'tarjeta', 'cantidad' => $cant, 'stock' => (int)$t['stock'],
                'precio' => (float)$t['precio'], 'precio_normal' => (float)$t['precio'],
                'titulo' => 'Tarjeta PSN ' . dinero($t['monto']), 'detalle' => 'Código digital de saldo',
                'digital' => true, 'url' => 'tarjetas-psn.php',
                'arte' => null, 'edicion_id' => null, 'tarjeta_id' => $t['id'], 'monto' => $t['monto'],
            ];
        }
    }
    return $items;
}

function carritoTotales($items, $usarPuntos = false, $puntosDisponibles = 0) {
    $subtotal = 0; $puntosGanados = 0; $hayFisico = false;
    foreach ($items as $it) {
        $subtotal += $it['precio'] * $it['cantidad'];
        if ($it['tipo'] === 'juego') $puntosGanados += floor($it['precio'] * PUNTOS_POR_PESO) * $it['cantidad'];
        if (!$it['digital']) $hayFisico = true;
    }
    $puntosUsados = $usarPuntos ? (int)min($puntosDisponibles, floor($subtotal * MAX_DESCUENTO_PUNTOS / VALOR_PUNTO)) : 0;
    $descuento = $puntosUsados * VALOR_PUNTO;
    return [
        'subtotal' => $subtotal, 'descuento' => $descuento, 'total' => $subtotal - $descuento,
        'puntos_usados' => $puntosUsados, 'puntos_ganados' => (int)$puntosGanados, 'hay_fisico' => $hayFisico,
        'maximo_puntos' => (int)min($puntosDisponibles, floor($subtotal * MAX_DESCUENTO_PUNTOS / VALOR_PUNTO)),
    ];
}

// Código digital tipo XXXX-XXXX-XXXX (sin letras confusas como O, 0, I, 1)
function generarCodigo() {
    $letras = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $c = '';
    for ($i = 0; $i < 12; $i++) $c .= $letras[random_int(0, strlen($letras) - 1)];
    return implode('-', str_split($c, 4));
}

function nombreMetodo($m) {
    return ['tarjeta' => 'Tarjeta de crédito/débito', 'paypal' => 'PayPal', 'mercadopago' => 'Mercado Pago', 'oxxo' => 'OXXO Pay'][$m] ?? $m;
}

function referenciaOxxo($pedidoId) {
    return '9300 ' . implode(' ', str_split(str_pad((string)($pedidoId * 7919 % 100000000), 8, '0', STR_PAD_LEFT), 4));
}

// Estados del pedido con su nombre y color
function estadoPedido($estado) {
    $e = [
        'pagado' => ['Pagado', 'preventa'], 'preparando' => ['Preparando', 'pocas'],
        'enviado' => ['Enviado', 'info'], 'entregado' => ['Entregado', 'disponible'], 'cancelado' => ['Cancelado', 'agotado'],
    ];
    [$texto, $clase] = $e[$estado] ?? [$estado, 'agotado'];
    return '<span class="insignia ' . $clase . '">' . $texto . '</span>';
}

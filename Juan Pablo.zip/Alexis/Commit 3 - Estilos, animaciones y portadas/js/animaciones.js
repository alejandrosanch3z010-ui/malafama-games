// =====================================================================
//  Animaciones con GSAP (solo en momentos puntuales):
//  logo de neón, catálogo con Flip, contador del carrito,
//  folio/códigos del pedido y cifras del dashboard.
//  Si la persona pidió "reducir movimiento" en su sistema, no se anima nada.
// =====================================================================
(function () {
    const MF_ANIM = window.MF_ANIM = {
        activo: false,
        rebote() {}, kpis() {}, reacomodar() {},
    };
    if (!window.gsap) return;
    gsap.registerPlugin(Flip, DrawSVGPlugin, ScrambleTextPlugin);

    const LETRAS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    const mm = gsap.matchMedia();

    mm.add("(prefers-reduced-motion: no-preference)", () => {
        MF_ANIM.activo = true;

        // 1) Logo: los tubos de neón se dibujan, salen los cuernos y parpadea al encender (una vez por sesión)
        const logo = document.querySelector(".tienda-nav .logo-svg");
        if (logo && !sessionStorage.getItem("mf-logo")) {
            sessionStorage.setItem("mf-logo", "1");
            gsap.timeline({ delay: .2 })
                .from(logo.querySelectorAll(".tubo"), { drawSVG: 0, duration: 1, ease: "power2.inOut", stagger: .3 })
                .from(logo.querySelectorAll(".cuerno"), { scale: 0, transformOrigin: "50% 100%", duration: .45, ease: "back.out(3)", stagger: .1 }, "-=.35")
                .from(".tienda-nav .logo-texto", { opacity: 0, x: -10, duration: .5, ease: "power2.out" }, "-=.5")
                .to(logo, { opacity: .35, duration: .06, repeat: 3, yoyo: true, ease: "none" });
        }

        // 2) Contador del carrito: rebota cuando cambia
        MF_ANIM.rebote = icono => {
            gsap.fromTo(icono.querySelector(".burbuja"), { scale: 1.9 }, { scale: 1, duration: .7, ease: "elastic.out(1, .4)" });
            gsap.fromTo(icono.querySelector("svg"), { rotation: -14 }, { rotation: 0, duration: .6, ease: "elastic.out(1, .3)" });
        };

        // 3) Catálogo: las tarjetas que siguen se deslizan a su nuevo lugar y las nuevas aparecen
        MF_ANIM.reacomodar = (rejilla, estadoAntes) => {
            const tarjetas = rejilla.querySelectorAll(".tj");
            if (!estadoAntes) {
                gsap.from(tarjetas, { opacity: 0, y: 18, duration: .45, ease: "power2.out", stagger: .04 });
                return;
            }
            Flip.from(estadoAntes, {
                targets: tarjetas, duration: .55, ease: "power2.inOut", scale: true, absolute: true,
                onEnter: nuevas => gsap.fromTo(nuevas, { opacity: 0, scale: .9 }, { opacity: 1, scale: 1, duration: .45, stagger: .04 }),
            });
        };

        // 4) Dashboard: tarjetas escalonadas y cifras que cuentan desde cero
        MF_ANIM.kpis = contenedor => {
            gsap.from(contenedor.querySelectorAll(".kpi"), { opacity: 0, y: 16, duration: .5, ease: "power2.out", stagger: .07 });
            contenedor.querySelectorAll("[data-contar]").forEach(el => {
                const valor = Number(el.dataset.contar), obj = { n: 0 };
                gsap.to(obj, {
                    n: valor, duration: 1.3, ease: "power3.out",
                    onUpdate: () => { el.textContent = el.dataset.formato === "pesos" ? pesos(obj.n) : Math.round(obj.n); },
                });
            });
        };

        // 5) Pedido confirmado: al cerrar el aviso, el folio y los códigos se "descifran"
        document.querySelectorAll("[data-cerrar-aviso]").forEach(b => b.addEventListener("click", () => {
            document.querySelectorAll("[data-descifrar]").forEach((el, i) => {
                gsap.to(el, { duration: 1.3, delay: .15 + i * .15, scrambleText: { text: el.textContent, chars: LETRAS, speed: .6, revealDelay: .3 } });
            });
        }));

        return () => { MF_ANIM.activo = false; MF_ANIM.rebote = MF_ANIM.kpis = MF_ANIM.reacomodar = () => {}; };
    });
})();

// =====================================================================
//  Catálogo: consulta GET /api/juegos con búsqueda, filtros, orden y
//  paginación. La dirección de la página se actualiza para poder compartirla.
// =====================================================================
(function () {
    const form = document.getElementById("filtros");
    const rejilla = document.getElementById("rejilla");
    const estado = document.getElementById("estado-carga");
    const conteo = document.getElementById("conteo");
    const paginacion = document.getElementById("paginacion");
    let pagina = Number(new URLSearchParams(location.search).get("page")) || 1;
    let peticion = 0;

    function tarjeta(j) {
        const url = "juego.php?j=" + encodeURIComponent(j.slug);
        const arte = j.portada_cuadrada
            ? `<img class="portada" src="${esc(j.portada_cuadrada)}" alt="${esc(j.titulo)}" loading="lazy">`
            : `<div class="portada portada-vacia" style="--tono:${j.tono}" role="img" aria-label="${esc(j.titulo)}"><span>${esc(j.titulo)}</span></div>`;
        return `<article class="tj" data-flip-id="${esc(j.slug)}"><a href="${url}" class="tj-enlace">
            <div class="tj-arte">${arte}</div>
            <span class="insignia ${j.estado_stock.clase}">${esc(j.estado_stock.texto)}</span>
            <div class="tj-info">
                <p class="tj-meta"><span class="ps5">PS5</span>${j.total_resenas ? `<span class="tj-cal">★ ${j.calificacion.toFixed(1)}</span>` : ""}</p>
                <h3>${esc(j.titulo)}</h3>
                ${j.preventa ? `<p class="tj-extra">Sale el ${esc(j.fecha_texto)}</p>` : ""}
                <p class="tj-precio">${j.descuento ? `<span class="desc">-${j.descuento}%</span>` : ""}<strong>${pesos(j.precio_final)} MXN</strong>${j.descuento ? `<del>${pesos(j.precio_normal)} MXN</del>` : ""}</p>
            </div></a></article>`;
    }

    function mostrarEstado(html) {
        estado.innerHTML = html;
        estado.hidden = !html;
    }

    function dibujarPaginacion(r) {
        if (r.totalPaginas <= 1) { paginacion.innerHTML = ""; return; }
        let html = `<button type="button" data-pagina="${r.pagina - 1}" ${r.pagina <= 1 ? "disabled" : ""} aria-label="Página anterior">‹</button>`;
        for (let i = 1; i <= r.totalPaginas; i++) {
            html += `<button type="button" data-pagina="${i}" ${i === r.pagina ? 'aria-current="page" class="activa"' : ""}>${i}</button>`;
        }
        html += `<button type="button" data-pagina="${r.pagina + 1}" ${r.pagina >= r.totalPaginas ? "disabled" : ""} aria-label="Página siguiente">›</button>`;
        paginacion.innerHTML = html;
    }

    async function cargar() {
        const params = new URLSearchParams();
        new FormData(form).forEach((v, k) => { if (v !== "" && k !== "csrf") params.set(k, v); });
        params.set("page", pagina);
        params.set("limit", 12);
        history.replaceState(null, "", "catalogo.php?" + params.toString());

        const id = ++peticion;
        rejilla.setAttribute("aria-busy", "true");
        rejilla.classList.add("cargando");
        mostrarEstado(rejilla.children.length ? "" : '<div class="spinner" aria-hidden="true"></div><p>Cargando juegos…</p>');
        try {
            const r = await api("juegos?" + params.toString());
            if (id !== peticion) return; // llegó una búsqueda más nueva
            // Flip: se guarda dónde estaba cada tarjeta, se dibujan las nuevas y GSAP anima el cambio
            const anim = window.MF_ANIM?.activo && window.Flip;
            const estadoAntes = anim && rejilla.children.length ? Flip.getState(rejilla.querySelectorAll(".tj")) : null;
            rejilla.classList.remove("cargando");
            rejilla.innerHTML = r.datos.map(tarjeta).join("");
            if (anim) window.MF_ANIM.reacomodar(rejilla, estadoAntes);
            conteo.textContent = `${r.total} ${r.total === 1 ? "juego" : "juegos"}` + (r.totalPaginas > 1 ? ` · página ${r.pagina} de ${r.totalPaginas}` : "");
            mostrarEstado(r.total ? "" : '<h2>Sin resultados</h2><p>Prueba con otros filtros o busca otro título.</p><a class="btn" href="catalogo.php">Ver todo el catálogo</a>');
            dibujarPaginacion(r);
            if (r.pagina > r.totalPaginas && r.total) { pagina = r.totalPaginas; cargar(); }
        } catch (err) {
            if (id !== peticion) return;
            rejilla.innerHTML = "";
            paginacion.innerHTML = "";
            conteo.textContent = "";
            mostrarEstado(`<h2>No pudimos cargar el catálogo</h2><p>${esc(err.message)}</p><button type="button" class="btn" id="reintentar">Reintentar</button>`);
        } finally {
            if (id === peticion) { rejilla.removeAttribute("aria-busy"); rejilla.classList.remove("cargando"); }
        }
    }

    // Cambiar un filtro reinicia a la página 1; escribir en el buscador espera a que dejes de teclear
    let espera;
    form.addEventListener("input", e => {
        if (e.target.name !== "q") return;
        clearTimeout(espera);
        espera = setTimeout(() => { pagina = 1; cargar(); }, 350);
    });
    form.addEventListener("change", e => { if (e.target.name !== "q") { pagina = 1; cargar(); } });
    form.addEventListener("submit", e => { e.preventDefault(); pagina = 1; cargar(); });
    form.querySelector('a[href="catalogo.php"]')?.addEventListener("click", e => {
        e.preventDefault();
        form.reset();
        form.querySelectorAll("input[type=search]").forEach(i => { i.value = ""; });
        form.querySelectorAll("select").forEach(s => { s.selectedIndex = 0; });
        form.querySelectorAll('input[type=radio][value=""]').forEach(r => { r.checked = true; });
        pagina = 1; cargar();
    });
    paginacion.addEventListener("click", e => {
        const b = e.target.closest("button[data-pagina]");
        if (!b || b.disabled) return;
        pagina = Number(b.dataset.pagina);
        cargar().then(() => document.querySelector(".catalogo-cabecera").scrollIntoView({ behavior: "smooth" }));
    });
    estado.addEventListener("click", e => { if (e.target.id === "reintentar") cargar(); });

    cargar();
})();

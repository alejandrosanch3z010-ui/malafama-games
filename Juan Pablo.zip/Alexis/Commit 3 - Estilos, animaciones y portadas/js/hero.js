(function () {
    const hero = document.querySelector(".mf-hero");
    if (!hero) return;

    const canvas = document.getElementById("mfCanvas");
    const ring = document.getElementById("ring");
    const nav = document.getElementById("hnav");
    const burger = document.getElementById("burger");
    const $ = id => document.getElementById(id);

    const CW = 1172, TAB_MAX = 1080, TAB_MIN = 701, DW_MIN = 920;
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    let k = 1, mobile = false;

    /* ---------- Cielo estrellado: dos capas hechas con box-shadow ---------- */
    function estrellas(el, n, blur, a0, a1) {
        const s = [];
        for (let i = 0; i < n; i++) {
            s.push(`${(Math.random() * 100).toFixed(2)}vw ${(Math.random() * 100).toFixed(2)}vh ${blur}px 0 rgba(255,255,255,${(a0 + Math.random() * (a1 - a0)).toFixed(2)})`);
        }
        el.style.boxShadow = s.join(",");
    }
    estrellas($("stA"), 150, 0, .05, .30);
    estrellas($("stB"), 18, 1.2, .35, .70);

    /* ---------- Anillo 3D ----------
       37 portadas sobre un cilindro de radio R con la cámara en su centro (perspectiva = R),
       así cada portada queda tangente y mira de frente a la cámara. Paso = 360/37 grados;
       las que pasan de 42° se ocultan porque quedan detrás. */
    const R = 891, N = 37, PASO = 360 / N, CORTE = 42, VEL = 1.9;
    const juegos = window.MF_ANILLO || [];
    const esc = t => String(t).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

    function portada(d, i) {
        const fondo = d.portada
            ? `<img alt="" src="${esc(d.portada)}"><div class="fill" style="background:linear-gradient(180deg,rgba(4,8,16,0) 40%,rgba(4,8,16,.9) 75%)"></div>`
            : `<div class="fill cover-bg" style="--tono:${d.tono}"></div>`;
        const banda = `<div class="psband">PS5<small>${esc(d.genero.toUpperCase())}</small></div>`;
        // El texto va en la parte de arriba: es lo único que queda visible sobre el navegador de muestra
        const sombra = `<div class="fill" style="background:linear-gradient(180deg,rgba(4,8,16,.88) 0%,rgba(4,8,16,.45) 32%,rgba(4,8,16,0) 58%)"></div>`;
        if (d.portada) {
            // Portada real: solo la etiqueta de preventa u oferta y el precio abajo
            const etiqueta = d.preventa ? "PREVENTA" : d.desc > 0 ? `-${d.desc}%` : "";
            return fondo + banda
                + (etiqueta ? `<div style="position:absolute;left:8px;top:24px;padding:2px 6px;border-radius:4px;background:${d.preventa ? "#a36bff" : "#ff3fa4"};font-size:6px;font-weight:800;letter-spacing:.08em">${etiqueta}</div>` : "")
                + `<div class="fill" style="background:linear-gradient(180deg,rgba(4,8,16,0) 70%,rgba(4,8,16,.85) 100%)"></div>`
                + `<div class="cv" style="bottom:10px;font-size:7px;font-weight:700">${esc(d.precio)}</div><div class="edge"></div>`;
        }
        let arte;
        if (d.preventa) {
            arte = sombra + `<div style="position:absolute;left:-6px;right:-6px;top:24px;height:13px;background:#a36bff;transform:rotate(-2.6deg);box-shadow:0 4px 12px rgba(163,107,255,.5)"></div>
                <div style="position:absolute;left:0;right:0;top:25.5px;transform:rotate(-2.6deg);text-align:center;font-size:5.6px;font-weight:700;letter-spacing:.12em">PREVENTA</div>
                <div class="cv t-big" style="top:46px;font-size:15px">${esc(d.titulo)}</div>
                <div class="cv" style="top:84px;font-size:5.2px;letter-spacing:.08em;opacity:.85">SALE EL ${esc(d.fecha.toUpperCase())}</div>`;
        } else if (d.desc > 0) {
            arte = sombra + `<div class="cv t-big" style="top:26px;font-size:9px;opacity:.9">${esc(d.titulo)}</div>
                <div class="cv t-big" style="top:48px;font-size:24px;color:#3fe3ff;text-shadow:0 0 16px rgba(63,227,255,.5)">-${d.desc}%</div>
                <div class="cv" style="top:76px;font-size:6px;font-weight:700">${esc(d.precio)} <s style="opacity:.6;font-weight:400">${esc(d.normal)}</s></div>`;
        } else if (i % 2) {
            arte = sombra + `<div class="cv t-serif" style="top:28px;font-size:15px">${esc(d.titulo)}</div>
                <div class="cv" style="top:76px;font-size:5.4px;font-weight:700"><b class="dot"></b>${esc(d.precio)}</div>`;
        } else {
            arte = sombra + `<div class="cv t-big" style="top:28px;font-size:15px">${esc(d.titulo)}</div>
                <div class="cv" style="top:76px;font-size:5px;font-weight:600;letter-spacing:.2em">${esc(d.precio)}</div>`;
        }
        return fondo + banda + arte + '<div class="edge"></div>';
    }

    const tarjetas = [];
    if (juegos.length) {
        for (let i = 0; i < N; i++) {
            const el = document.createElement("div");
            el.className = "card";
            el.innerHTML = portada(juegos[i % juegos.length], i);
            const img = el.querySelector("img");
            if (img) img.addEventListener("error", () => el.classList.add("broken"));
            ring.appendChild(el);
            tarjetas.push(el);
        }
    }

    let fase = -2, ultimo = 0;
    function colocarTarjetas() {
        tarjetas.forEach((el, i) => {
            const a = ((i * PASO + fase) % 360 + 540) % 360 - 180; // ángulo con signo, -180..180
            if (Math.abs(a) > CORTE) { el.style.visibility = "hidden"; return; }
            el.style.visibility = "visible";
            const r = a * Math.PI / 180, c = Math.cos(r);
            el.style.transform = `translate3d(${R * Math.sin(r)}px,0,${R * (1 - c)}px) rotateY(${-a}deg)`;
            el.style.filter = `brightness(${0.84 + 0.5 * (1 / c - 1)})`; // orillas oscuras, frente brillante
        });
    }
    function girar(t) {
        const dt = ultimo ? Math.min((t - ultimo) / 1000, .1) : 0;
        ultimo = t;
        if (!reduce) fase -= VEL * dt;
        colocarTarjetas();
        requestAnimationFrame(girar);
    }
    document.addEventListener("visibilitychange", () => { ultimo = 0; });

    /* ---------- Ajuste tipográfico ----------
       Cada texto se escala para que su ancho y altura de mayúscula coincidan con el diseño.
       Las métricas se leen de un canvas 2D. Como nuestros textos no miden lo mismo que el
       diseño original, el estirado horizontal se limita para no deformar las letras. */
    const ctx = document.createElement("canvas").getContext("2d");
    const fuente = (el, size) => { const cs = getComputedStyle(el); return `${cs.fontWeight} ${size || cs.fontSize} ${cs.fontFamily}`; };
    function capRatio(el) { ctx.font = fuente(el, "100px"); return (ctx.measureText("H").actualBoundingBoxAscent || 70) / 100; }
    const ancho = el => el.getBoundingClientRect().width / (mobile ? 1 : k);
    function fitBox(el, tw, tc, pre = "") {
        el.style.transform = pre;
        el.style.fontSize = (tc / capRatio(el)) + "px";
        const s = Math.max(.82, Math.min(1.18, tw / ancho(el)));
        el.style.transform = `${pre} scaleX(${s})`.trim();
    }
    function metricas(el) {
        const size = parseFloat(getComputedStyle(el).fontSize);
        ctx.font = fuente(el);
        const m = ctx.measureText("H");
        return { size, A: m.fontBoundingBoxAscent || size * .8, D: m.fontBoundingBoxDescent || size * .2 };
    }
    function baseline(el, y) {
        const { size, A, D } = metricas(el);
        el.style.top = (y - ((size - (A + D)) / 2 + A)) + "px";
    }
    function centrarEtiqueta(btn, el, capPx) {
        el.style.top = "0px";
        const { size, A, D } = metricas(el);
        const base = (btn.offsetHeight - size) / 2 + (size - (A + D)) / 2 + A; // línea base respecto al botón
        el.style.top = (btn.offsetHeight / 2 - (base - capPx / 2) + 1.1) + "px";
    }
    const ajustados = ["h1a", "h1b", "sub1", "sub2", "badgeTxt", "wmName", "ctaLabel", "vpLabel"];
    function limpiar() {
        ajustados.forEach(id => { const s = $(id).style; s.fontSize = ""; s.top = ""; s.transform = ""; });
        const links = $("links");
        links.style.transform = "";
        [...links.children].forEach(a => { a.style.fontSize = ""; });
    }

    function layout() {
        const vw = hero.clientWidth, vh = hero.clientHeight;
        mobile = vw <= 700;
        const tablet = !mobile && vw <= TAB_MAX;
        const cs = canvas.style;

        if (mobile) {
            k = 1;
            ["--k", "--fill", "--stshift", "--sshift", "--rs"].forEach(p => cs.removeProperty(p));
            limpiar();
            colocarTarjetas();
            return;
        }

        // k = min(vw/W, vh/560): se usa 560 y no 657 para llenar el ancho y dejar que el
        // navegador de muestra se salga por abajo en lugar de dejar franjas vacías.
        let W = CW, ss = 0, rs = 1, st = 0, T = 1;
        if (tablet) {
            W = DW_MIN + (vw - TAB_MIN) * (CW - DW_MIN) / (TAB_MAX - TAB_MIN);
            if (vh > vw * 1.15) W = Math.min(W, 900);
        }
        k = Math.min(vw / W, vh / 560);
        let fill = Math.max(0, vh / k - 657);
        if (tablet) {
            // El alto sobrante se reparte en tres: el anillo baja, el anillo crece y el titular se centra
            const ramp = Math.min(1, (TAB_MAX - vw) / 120);
            T = 1 + .14 * ramp;
            if (fill > 0) {
                ss = Math.min(fill * .55, 420) * ramp;
                rs = 1 + Math.min(fill / 1100, .75) * ramp;
                const slack = 219.5 - 125 * rs + ss;
                st = Math.max(0, slack / 2 - 28) * ramp;
                fill -= ss;
            }
        }
        cs.setProperty("--k", k);
        cs.setProperty("--fill", fill + "px");
        cs.setProperty("--stshift", st + "px");
        cs.setProperty("--sshift", ss + "px");
        cs.setProperty("--rs", rs);

        fitBox($("h1a"), 563.5 * T, 37.2 * T, "translateX(-50%)"); baseline($("h1a"), 204.5);
        fitBox($("h1b"), 197.5 * T, 37.2 * T, "translateX(-50%)"); baseline($("h1b"), 258.5);
        fitBox($("sub1"), 389 * T, 8.4 * T, "translateX(-50%)"); baseline($("sub1"), 300.5);
        fitBox($("sub2"), 311 * T, 8.4 * T, "translateX(-50%)"); baseline($("sub2"), 316.5);
        fitBox($("badgeTxt"), (tablet ? 211 : 184) * T, 9.4 * T, "translate(2px,-1px)");
        fitBox($("wmName"), 74 * T, 11.4 * T); baseline($("wmName"), 38.5);
        fitBox($("ctaLabel"), 87 * T, 8.9 * T); centrarEtiqueta($("ctaLabel").parentNode, $("ctaLabel"), 8.9 * T);
        fitBox($("vpLabel"), 76 * T, 9.5 * T); centrarEtiqueta($("vpLabel").parentNode, $("vpLabel"), 9.5 * T);

        const links = $("links");
        links.style.transform = "";
        if (tablet) {
            [...links.children].forEach(a => { a.style.fontSize = ""; });
        } else {
            const fs = 7.9 / capRatio(links.children[0]);
            [...links.children].forEach(a => { a.style.fontSize = fs + "px"; });
            links.style.transform = `scaleX(${317 / ancho(links)})`;
        }
        colocarTarjetas();
    }

    /* ---------- Menú (tablet y celular) ---------- */
    function cerrarMenu(regresarFoco) {
        nav.classList.remove("open");
        burger.setAttribute("aria-expanded", "false");
        if (regresarFoco) burger.focus();
    }
    burger.addEventListener("click", e => {
        e.stopPropagation();
        const abierto = nav.classList.toggle("open");
        burger.setAttribute("aria-expanded", abierto);
    });
    document.addEventListener("click", e => { if (!nav.contains(e.target)) cerrarMenu(); });
    document.addEventListener("keydown", e => { if (e.key === "Escape" && nav.classList.contains("open")) cerrarMenu(true); });
    $("navmenu").addEventListener("click", e => { if (e.target.closest("a")) cerrarMenu(); });

    function resize() {
        if (hero.clientWidth > TAB_MAX) cerrarMenu();
        layout();
    }
    addEventListener("resize", resize);
    if (window.visualViewport) visualViewport.addEventListener("resize", resize);
    resize();
    if (document.fonts) document.fonts.ready.then(layout);
    setTimeout(layout, 400);
    setTimeout(layout, 1400);
    requestAnimationFrame(girar);

    /* ---------- Entrada: una sola vez y luego la página queda quieta ---------- */
    (function () {
        const html = document.documentElement;
        const settle = () => {
            document.getAnimations().forEach(a => { if (String(a.id).startsWith("intro:")) a.cancel(); });
            html.classList.remove("intro");
        };
        if (!html.classList.contains("intro") || reduce || !Element.prototype.animate) { settle(); return; }

        const D = innerWidth <= 700 ? .66 : 1;
        const EXPO = "cubic-bezier(.16,1,.3,1)", SOFT = "cubic-bezier(.22,.61,.36,1)";
        const Y = px => `0 ${px * D}px`;
        let n = 0, ultima = null, fin = 0;
        function play(el, from, dur, delay, ease) {
            if (!el) return;
            const to = { opacity: 1 };
            if (from.translate) to.translate = "0 0";
            if (from.scale) to.scale = "1";
            if (from.clipPath) to.clipPath = "inset(-30% 0 -30% 0)";
            const a = el.animate([from, to], { duration: dur, delay, easing: ease, fill: "both" });
            a.id = "intro:" + n++;
            if (dur + delay > fin) { fin = dur + delay; ultima = a; }
        }
        const q = s => hero.querySelector(s);
        play(nav, { opacity: 0, translate: Y(-9) }, 620, 60, EXPO);
        play(q(".mark"), { opacity: 0, translate: Y(6) }, 520, 150, SOFT);
        play(q(".wm"), { opacity: 0, translate: Y(6) }, 520, 185, SOFT);
        hero.querySelectorAll(".links a").forEach((a, i) => play(a, { opacity: 0, translate: Y(6) }, 460, 215 + i * 45, SOFT));
        play(burger, { opacity: 0, translate: Y(6) }, 460, 300, SOFT);
        play(q(".hnav .gbtn"), { opacity: 0, translate: Y(6) }, 500, 400, SOFT);
        play(q(".badge"), { opacity: 0, translate: Y(11), scale: .985 }, 560, 270, EXPO);
        play($("h1a"), { opacity: 0, translate: Y(15), clipPath: "inset(100% 0 -30% 0)" }, 900, 380, EXPO);
        play($("h1b"), { opacity: 0, translate: Y(15), clipPath: "inset(100% 0 -30% 0)" }, 900, 470, EXPO);
        play($("sub1"), { opacity: 0, translate: Y(10) }, 620, 690, EXPO);
        play($("sub2"), { opacity: 0, translate: Y(10) }, 620, 745, EXPO);
        play(q(".cta2"), { opacity: 0, translate: Y(13), scale: .985 }, 620, 830, EXPO);
        play(ring, { opacity: 0, translate: Y(18), scale: .99 }, 950, 700, EXPO);
        play(q(".browser"), { opacity: 0, translate: Y(26) }, 900, 900, EXPO);
        play(q(".wa"), { opacity: 0, scale: .88 }, 500, 1260, EXPO);
        if (ultima) ultima.finished.then(settle).catch(settle); else settle();
    })();
})();

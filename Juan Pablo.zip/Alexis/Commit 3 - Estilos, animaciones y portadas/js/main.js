// Buscador de la barra de la tienda
const buscarBtn = document.getElementById("buscar-btn");
const buscador = document.getElementById("buscador-tienda");
if (buscarBtn && buscador) {
    buscarBtn.addEventListener("click", () => {
        buscador.hidden = !buscador.hidden;
        buscarBtn.setAttribute("aria-expanded", !buscador.hidden);
        if (!buscador.hidden) buscador.querySelector("input").focus();
    });
}

// Íconos y botones que todavía no tienen su fase
document.querySelectorAll("[data-proximo]").forEach(b => b.addEventListener("click", () => avisar(b.dataset.proximo)));

// Filtros del catálogo en celular
const filtrosBtn = document.getElementById("filtros-btn");
const filtros = document.getElementById("filtros");
// Los filtros se aplican solos al cambiar una opción (el botón "Aplicar" queda solo por si no hay JavaScript)
if (filtros && !filtros.dataset.js) {
    filtros.classList.add("auto");
    filtros.addEventListener("change", () => {
        filtros.classList.add("cargando");
        filtros.requestSubmit ? filtros.requestSubmit() : filtros.submit();
    });
}
if (filtrosBtn && filtros) {
    filtrosBtn.addEventListener("click", () => {
        const abierto = filtros.classList.toggle("abierto");
        filtrosBtn.setAttribute("aria-expanded", abierto);
    });
}

// Flechas de las filas horizontales
document.querySelectorAll(".fila").forEach(fila => {
    const pista = fila.querySelector(".fila-pista");
    if (!pista) return;
    fila.querySelectorAll(".flecha").forEach(f => f.addEventListener("click", () => {
        pista.scrollBy({ left: pista.clientWidth * 0.8 * Number(f.dataset.dir), behavior: "smooth" });
    }));
});

// Contadores de preventa: días, horas, minutos y segundos para el lanzamiento
function actualizarContadores() {
    document.querySelectorAll(".contador").forEach(el => {
        const [a, m, d] = el.dataset.fecha.split("-").map(Number);
        const falta = new Date(a, m - 1, d) - new Date();
        if (falta <= 0) { el.innerHTML = "<span>¡Ya disponible!</span>"; return; }
        const partes = [
            [Math.floor(falta / 86400000), "días"],
            [Math.floor(falta / 3600000) % 24, "hrs"],
            [Math.floor(falta / 60000) % 60, "min"],
            [Math.floor(falta / 1000) % 60, "seg"],
        ];
        el.innerHTML = partes.map(([n, t]) => `<span><b>${String(n).padStart(2, "0")}</b>${t}</span>`).join("");
    });
}
actualizarContadores();
setInterval(actualizarContadores, 1000);

// Letreros de neón: se encienden (parpadeo corto) la primera vez que aparecen en pantalla
const letreros = document.querySelectorAll(".neon");
if ("IntersectionObserver" in window && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const obs = new IntersectionObserver(entradas => entradas.forEach(en => {
        if (en.isIntersecting) { en.target.classList.add("encendido"); obs.unobserve(en.target); }
    }), { threshold: .6 });
    letreros.forEach(l => obs.observe(l));
} else {
    letreros.forEach(l => l.classList.add("encendido"));
}

// Pago: muestra solo los campos del método elegido
const metodos = document.querySelectorAll('input[name="metodo"]');
function mostrarMetodo() {
    const elegido = document.querySelector('input[name="metodo"]:checked')?.value;
    document.querySelectorAll(".panel-metodo").forEach(p => { p.hidden = p.dataset.metodo !== elegido; });
}
metodos.forEach(m => m.addEventListener("change", mostrarMetodo));
if (metodos.length) mostrarMetodo();

// Formato del número de tarjeta en bloques de 4
const numTarjeta = document.querySelector('input[name="tarjeta_numero"]');
if (numTarjeta) numTarjeta.addEventListener("input", () => {
    numTarjeta.value = numTarjeta.value.replace(/\D/g, "").slice(0, 16).replace(/(\d{4})(?=\d)/g, "$1 ");
});

// Total en vivo al usar puntos
const usarPuntos = document.querySelector('input[name="usar_puntos"]');
const totalPagar = document.getElementById("total-pagar");
if (usarPuntos && totalPagar) {
    usarPuntos.addEventListener("change", () => {
        const desc = usarPuntos.checked ? Number(usarPuntos.dataset.descuento) : 0;
        document.getElementById("linea-puntos").textContent = "−" + pesos(desc);
        const total = Number(totalPagar.dataset.subtotal) - desc;
        totalPagar.textContent = pesos(total) + " MXN";
        const iva = document.getElementById("iva-pagar");
        if (iva) iva.textContent = pesos(total - total / 1.16);
    });
}

// Copiar códigos digitales
document.querySelectorAll("[data-copiar]").forEach(b => b.addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(b.dataset.copiar); b.textContent = "¡Copiado!"; }
    catch { b.textContent = "Selecciónalo y cópialo"; }
    setTimeout(() => { b.textContent = "Copiar"; }, 1800);
}));

// Cierra el menú de cuenta al hacer clic fuera o con Escape
const menuCuenta = document.querySelector(".cuenta");
if (menuCuenta) {
    document.addEventListener("click", e => { if (!menuCuenta.contains(e.target)) menuCuenta.open = false; });
    document.addEventListener("keydown", e => { if (e.key === "Escape") menuCuenta.open = false; });
}

// Si el navegador restaura la página desde su memoria al usar Atrás/Adelante, se recarga para mostrar datos al día
addEventListener("pageshow", e => { if (e.persisted) location.reload(); });

// El aviso escolar se enciende al instante (el letrero está dentro de una ventana)
document.querySelectorAll(".aviso-escolar .neon").forEach(n => n.classList.add("encendido"));

// Cerrar el aviso escolar
document.querySelectorAll("[data-cerrar-aviso]").forEach(b => {
    b.focus();
    b.addEventListener("click", () => b.closest(".aviso-escolar").remove());
});
document.addEventListener("keydown", e => { if (e.key === "Escape") document.querySelector(".aviso-escolar")?.remove(); });

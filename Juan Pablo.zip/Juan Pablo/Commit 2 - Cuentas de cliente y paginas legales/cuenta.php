<?php
require_once 'includes/funciones.php';
requiereLogin();
$u = usuarioActual();
$secciones = ['resumen' => 'Resumen', 'pedidos' => 'Mis pedidos', 'codigos' => 'Mis códigos', 'puntos' => 'Mis puntos', 'perfil' => 'Mis datos'];
$s = isset($secciones[$_GET['s'] ?? '']) ? $_GET['s'] : 'resumen';
$errores = [];

$st = db()->prepare('SELECT * FROM usuarios WHERE id = ?');
$st->execute([$u['id']]);
$perfil = $st->fetch();

// ---------- Guardar datos o cambiar contraseña ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verificarCsrf();
    if (($_POST['accion'] ?? '') === 'perfil') {
        $s = 'perfil';
        $perfil['nombre'] = trim($_POST['nombre'] ?? '');
        $perfil['email'] = trim($_POST['email'] ?? '');
        $perfil['telefono'] = trim($_POST['telefono'] ?? '');
        $perfil['direccion'] = trim($_POST['direccion'] ?? '');
        if (mb_strlen($perfil['nombre']) < 2 || mb_strlen($perfil['nombre']) > 100) $errores['nombre'] = 'Escribe tu nombre (de 2 a 100 letras).';
        if (!filter_var($perfil['email'], FILTER_VALIDATE_EMAIL)) $errores['email'] = 'Escribe un correo válido.';
        if ($perfil['telefono'] !== '' && !preg_match('/^\d{10}$/', preg_replace('/\D/', '', $perfil['telefono']))) $errores['telefono'] = 'El teléfono debe tener 10 dígitos.';
        if (!isset($errores['email'])) {
            $st = db()->prepare('SELECT 1 FROM usuarios WHERE email = ? AND id <> ?');
            $st->execute([$perfil['email'], $u['id']]);
            if ($st->fetchColumn()) $errores['email'] = 'Ese correo ya lo usa otra cuenta.';
        }
        if (!$errores) {
            db()->prepare('UPDATE usuarios SET nombre = ?, email = ?, telefono = ?, direccion = ? WHERE id = ?')
                ->execute([$perfil['nombre'], $perfil['email'], $perfil['telefono'] ?: null, $perfil['direccion'] ?: null, $u['id']]);
            flash('Guardamos tus datos.');
            redirigir('cuenta.php?s=perfil');
        }
    }
    if (($_POST['accion'] ?? '') === 'password') {
        $s = 'perfil';
        if (!password_verify($_POST['actual'] ?? '', $perfil['password_hash'])) $errores['actual'] = 'Tu contraseña actual no coincide.';
        if (strlen($_POST['nueva'] ?? '') < 8) $errores['nueva'] = 'La nueva contraseña debe tener al menos 8 caracteres.';
        if (($_POST['nueva'] ?? '') !== ($_POST['nueva2'] ?? '')) $errores['nueva2'] = 'Las contraseñas no coinciden.';
        if (!$errores) {
            db()->prepare('UPDATE usuarios SET password_hash = ? WHERE id = ?')->execute([password_hash($_POST['nueva'], PASSWORD_DEFAULT), $u['id']]);
            session_regenerate_id(true);
            flash('Cambiaste tu contraseña.');
            redirigir('cuenta.php?s=perfil');
        }
    }
}

// ---------- Datos para cada sección ----------
$st = db()->prepare('SELECT p.*, (SELECT SUM(cantidad) FROM pedido_detalle WHERE pedido_id = p.id) AS piezas FROM pedidos p WHERE usuario_id = ? ORDER BY creado DESC');
$st->execute([$u['id']]);
$pedidos = $st->fetchAll();

$st = db()->prepare('SELECT c.codigo, c.creado, d.pedido_id, p.folio, j.titulo, e.version, t.monto
                     FROM codigos_digitales c
                     JOIN pedido_detalle d ON d.id = c.pedido_detalle_id
                     JOIN pedidos p ON p.id = d.pedido_id
                     LEFT JOIN ediciones e ON e.id = d.edicion_id LEFT JOIN juegos j ON j.id = e.juego_id
                     LEFT JOIN tarjetas_psn t ON t.id = d.tarjeta_id
                     WHERE p.usuario_id = ? AND c.activo = 1 ORDER BY c.creado DESC, c.id');
$st->execute([$u['id']]);
$codigos = $st->fetchAll();

$st = db()->prepare('SELECT * FROM puntos_movimientos WHERE usuario_id = ? ORDER BY creado DESC, id DESC');
$st->execute([$u['id']]);
$movimientos = $st->fetchAll();

$st = db()->prepare('SELECT COUNT(*) FROM resenas WHERE usuario_id = ?');
$st->execute([$u['id']]);
$totalResenas = (int)$st->fetchColumn();
$enCamino = count(array_filter($pedidos, fn($p) => in_array($p['estado'], ['pagado', 'preparando', 'enviado'])));

function err($errores, $k) { return isset($errores[$k]) ? '<small class="error-campo">' . e($errores[$k]) . '</small>' : ''; }

$titulo = $secciones[$s] . ' · Mi cuenta';
require 'includes/header.php';
?>
<div class="contenedor pagina cuenta-pagina">
    <div class="cuenta-cabecera">
        <span class="avatar grande" aria-hidden="true"><?= e(mb_strtoupper(mb_substr($perfil['nombre'], 0, 1))) ?></span>
        <div>
            <h1>Hola, <?= e(explode(' ', $perfil['nombre'])[0]) ?></h1>
            <p><?= e($perfil['email']) ?> · Cliente desde <?= fechaLarga($perfil['creado']) ?></p>
        </div>
        <div class="saldo-puntos">
            <?= letreroNeon($perfil['puntos'] . ' pts', 'amarillo') ?>
            <small>= <?= dinero($perfil['puntos'] * VALOR_PUNTO) ?> de descuento</small>
        </div>
    </div>

    <nav class="tabs cuenta-tabs" aria-label="Secciones de mi cuenta">
        <?php foreach ($secciones as $clave => $nombre): ?>
            <a href="cuenta.php?s=<?= $clave ?>" <?= $clave === $s ? 'class="activo" aria-current="page"' : '' ?>><?= $nombre ?></a>
        <?php endforeach; ?>
    </nav>

    <?php if ($s === 'resumen'): ?>
        <div class="cuenta-stats">
            <a href="cuenta.php?s=pedidos" class="stat"><b><?= count($pedidos) ?></b><span>Pedidos</span></a>
            <a href="cuenta.php?s=pedidos" class="stat"><b><?= $enCamino ?></b><span>En camino</span></a>
            <a href="cuenta.php?s=codigos" class="stat"><b><?= count($codigos) ?></b><span>Códigos digitales</span></a>
            <a href="deseos.php" class="stat"><b><?= contarDeseos($u['id']) ?></b><span>En mi lista de deseos</span></a>
            <a href="cuenta.php?s=puntos" class="stat"><b><?= $perfil['puntos'] ?></b><span>Puntos</span></a>
            <div class="stat"><b><?= $totalResenas ?></b><span>Reseñas escritas</span></div>
        </div>
        <?php if ($pedidos): $p = $pedidos[0]; ?>
            <section class="ficha-bloque">
                <h2>Tu último pedido</h2>
                <a class="fila-pedido" href="pedido.php?id=<?= $p['id'] ?>">
                    <b><?= e($p['folio']) ?></b><span><?= fechaLarga($p['creado']) ?></span><span><?= $p['piezas'] ?> productos</span>
                    <?= estadoPedido($p['estado']) ?><strong><?= dinero($p['total']) ?></strong>
                </a>
            </section>
        <?php else: ?>
            <div class="vacio"><h2>Todavía no tienes pedidos</h2><a class="btn" href="catalogo.php">Explorar juegos</a></div>
        <?php endif; ?>

    <?php elseif ($s === 'pedidos'): ?>
        <?php if ($pedidos): ?>
            <div class="lista-pedidos">
                <div class="fila-pedido cabecera" aria-hidden="true"><b>Pedido</b><span>Fecha</span><span>Productos</span><span>Estado</span><strong>Total</strong></div>
                <?php foreach ($pedidos as $p): ?>
                    <a class="fila-pedido" href="pedido.php?id=<?= $p['id'] ?>">
                        <b><?= e($p['folio']) ?></b><span><?= fechaLarga($p['creado']) ?></span>
                        <span><?= $p['piezas'] ?> <?= $p['piezas'] == 1 ? 'producto' : 'productos' ?> · <?= $p['direccion_envio'] ? 'Con envío' : 'Digital' ?></span>
                        <?= estadoPedido($p['estado']) ?><strong><?= dinero($p['total']) ?></strong>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="vacio"><h2>Todavía no tienes pedidos</h2><a class="btn" href="catalogo.php">Explorar juegos</a></div>
        <?php endif; ?>

    <?php elseif ($s === 'codigos'): ?>
        <?php if ($codigos): ?>
            <div class="lista-codigos">
                <?php foreach ($codigos as $c): ?>
                    <div class="fila-codigo">
                        <div><b><?= $c['titulo'] ? e($c['titulo'] . ($c['version'] !== 'Estándar' ? ' · ' . $c['version'] : '')) : 'Tarjeta PSN ' . dinero($c['monto']) ?></b>
                            <small>Pedido <a href="pedido.php?id=<?= $c['pedido_id'] ?>"><?= e($c['folio']) ?></a> · <?= fechaLarga($c['creado']) ?></small></div>
                        <div class="codigo"><code><?= e($c['codigo']) ?></code><button type="button" class="btn-copiar" data-copiar="<?= e($c['codigo']) ?>">Copiar</button></div>
                    </div>
                <?php endforeach; ?>
            </div>
            <p class="ayuda-pago">Canjéalos en tu PS5: PlayStation Store → ··· → Canjear código. (Códigos de demostración, no son reales).</p>
        <?php else: ?>
            <div class="vacio"><h2>No tienes códigos todavía</h2><p>Al comprar juegos digitales o tarjetas PSN, tus códigos aparecen aquí.</p><a class="btn" href="tarjetas-psn.php">Ver tarjetas PSN</a></div>
        <?php endif; ?>

    <?php elseif ($s === 'puntos'): ?>
        <div class="caja-form como-funciona">
            <h2>Así funcionan tus puntos</h2>
            <p>★ Por cada juego que compras ganas el <b><?= PUNTOS_POR_PESO * 100 ?>%</b> de su precio en puntos.</p>
            <p>★ Cada punto vale <b><?= dinero(VALOR_PUNTO) ?></b> y puedes usarlos para pagar hasta la <b>mitad</b> de tu siguiente compra.</p>
            <p>★ Las tarjetas PSN no generan puntos.</p>
        </div>
        <?php if ($movimientos): ?>
            <div class="lista-pedidos">
                <?php foreach ($movimientos as $m): ?>
                    <div class="fila-movimiento">
                        <span><?= e($m['concepto']) ?><small><?= fechaLarga($m['creado']) ?></small></span>
                        <b class="<?= $m['puntos'] > 0 ? 'mas' : 'menos' ?>"><?= $m['puntos'] > 0 ? '+' : '' ?><?= $m['puntos'] ?> pts</b>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="sin-contenido">Todavía no tienes movimientos de puntos.</p>
        <?php endif; ?>

    <?php else: ?>
        <div class="opiniones-grid">
            <form method="post" class="caja-form" novalidate data-api="perfil" data-metodo="PUT">
                <?= campoCsrf() ?><input type="hidden" name="accion" value="perfil">
                <h2>Mis datos</h2>
                <label>Nombre<input type="text" name="nombre" value="<?= e($perfil['nombre']) ?>" maxlength="100" autocomplete="name"><?= err($errores, 'nombre') ?></label>
                <label>Correo<input type="email" name="email" value="<?= e($perfil['email']) ?>" maxlength="120" autocomplete="email"><?= err($errores, 'email') ?></label>
                <label>Teléfono<input type="text" name="telefono" value="<?= e($perfil['telefono']) ?>" inputmode="numeric" autocomplete="tel"><?= err($errores, 'telefono') ?></label>
                <label>Dirección de envío<textarea name="direccion" rows="3" maxlength="255" autocomplete="street-address"><?= e($perfil['direccion']) ?></textarea></label>
                <button class="btn" type="submit">Guardar cambios</button>
            </form>
            <form method="post" class="caja-form" novalidate data-api="perfil/password" data-metodo="PATCH">
                <?= campoCsrf() ?><input type="hidden" name="accion" value="password">
                <h2>Cambiar contraseña</h2>
                <label>Contraseña actual<input type="password" name="actual" autocomplete="current-password"><?= err($errores, 'actual') ?></label>
                <label>Nueva contraseña<input type="password" name="nueva" autocomplete="new-password"><?= err($errores, 'nueva') ?: '<small class="ayuda">Mínimo 8 caracteres.</small>' ?></label>
                <label>Repite la nueva contraseña<input type="password" name="nueva2" autocomplete="new-password"><?= err($errores, 'nueva2') ?></label>
                <button class="btn" type="submit">Cambiar contraseña</button>
            </form>
        </div>
    <?php endif; ?>
</div>
<?php require 'includes/footer.php'; ?>

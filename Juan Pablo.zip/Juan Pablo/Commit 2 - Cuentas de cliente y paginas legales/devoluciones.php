<?php
require_once 'includes/funciones.php';
$titulo = 'Política de Devoluciones';
require 'includes/header.php';
?>
<article class="contenedor legal">
    <?= letreroNeon('Devoluciones', 'rosa') ?>
    <h1>Política de Devoluciones</h1>
    <p class="legal-fecha">Última actualización: 28 de septiembre de 2026</p>
    <p class="legal-aviso">Proyecto escolar: esta política es un ejemplo de cómo funcionaría en una tienda real.</p>

    <div class="legal-resumen">
        <div><b>Juegos físicos</b><span>30 días, sellados</span></div>
        <div><b>Juegos digitales</b><span>Solo si el código no funciona</span></div>
        <div><b>Preventas</b><span>Cancela antes del lanzamiento</span></div>
        <div><b>Tarjetas PSN</b><span>No reembolsables</span></div>
    </div>

    <h2>Juegos físicos</h2>
    <p>Tienes <b>30 días naturales</b> a partir de que recibes tu pedido para devolver un juego físico, siempre que esté <b>sellado y en su empaque original</b>. Una vez que se abre el juego, solo aceptamos devoluciones si el disco está dañado o no funciona; en ese caso lo cambiamos por otro igual o te reembolsamos.</p>
    <p>Si el paquete llega golpeado o con un producto distinto al que pediste, avísanos dentro de las primeras 48 horas y nosotros cubrimos el envío de regreso.</p>

    <h2>Juegos digitales</h2>
    <p>Por su naturaleza, <b>los códigos digitales no se pueden devolver una vez entregados</b>, ya que pueden canjearse al momento. Solo hacemos reembolso o cambio si:</p>
    <ul>
        <li>El código aparece como inválido o ya usado al intentar canjearlo por primera vez.</li>
        <li>Se te cobró dos veces el mismo pedido.</li>
        <li>Compraste el producto equivocado y <b>no has visto ni canjeado</b> el código (debes avisarnos el mismo día de la compra).</li>
    </ul>

    <h2>Preventas</h2>
    <p>Puedes cancelar una preventa en cualquier momento <b>antes de la fecha de lanzamiento</b> y te reembolsamos el total. Si la editorial retrasa el juego, también puedes cancelarla sin costo.</p>

    <h2>Tarjetas PSN</h2>
    <p>Las tarjetas de saldo de PlayStation Store no son reembolsables, salvo que el código no funcione.</p>

    <h2>Cómo solicitar una devolución</h2>
    <ol>
        <li>Entra a <a href="cuenta.php?s=pedidos">Mis pedidos</a> y ubica el número de tu pedido.</li>
        <li>Escríbenos con el número de pedido, el producto y el motivo (y fotos si llegó dañado).</li>
        <li>Te respondemos en un máximo de 3 días hábiles con las instrucciones de envío.</li>
    </ol>

    <h2>Reembolsos</h2>
    <p>Los reembolsos se hacen por el mismo medio de pago en un plazo de 5 a 10 días hábiles después de recibir y revisar el producto. Los pagos en OXXO se reembolsan por transferencia bancaria. Los puntos que usaste se te regresan y los que ganaste con esa compra se descuentan.</p>
</article>
<?php require 'includes/footer.php'; ?>

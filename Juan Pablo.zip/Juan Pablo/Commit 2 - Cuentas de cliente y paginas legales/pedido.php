<?php
require_once 'includes/funciones.php';
requiereLogin();
$u = usuarioActual();

// El dueño ve su pedido; el administrador y el empleado pueden ver todos
$st = db()->prepare('SELECT p.*, u.nombre AS cliente FROM pedidos p JOIN usuarios u ON u.id = p.usuario_id WHERE p.id = ?');
$st->execute([(int)($_GET['id'] ?? 0)]);
$pedido = $st->fetch();
$esDueno = $pedido && $pedido['usuario_id'] == $u['id'];
if (!$pedido || (!$esDueno && !puede('pedidos.ver_todos'))) {
    http_response_code(404);
    $titulo = 'Pedido no encontrado';
    require 'includes/header.php';
    echo '<div class="contenedor vacio"><h1>Pedido no encontrado</h1><a class="btn" href="index.php">Volver a la tienda</a></div>';
    require 'includes/footer.php';
    exit;
}

$st = db()->prepare('SELECT d.*, e.formato, e.version, j.id AS juego_id, j.titulo, j.slug, j.portada, t.monto
                     FROM pedido_detalle d
                     LEFT JOIN ediciones e ON e.id = d.edicion_id
                     LEFT JOIN juegos j ON j.id = e.juego_id
                     LEFT JOIN tarjetas_psn t ON t.id = d.tarjeta_id
                     WHERE d.pedido_id = ?');
$st->execute([$pedido['id']]);
$detalle = $st->fetchAll();

$st = db()->prepare('SELECT c.pedido_detalle_id, c.codigo, c.activo FROM codigos_digitales c JOIN pedido_detalle d ON d.id = c.pedido_detalle_id WHERE d.pedido_id = ?');
$st->execute([$pedido['id']]);
$codigos = [];
// Los códigos solo los ven el dueño y el administrador
if ($esDueno || $u['rol'] === 'admin') foreach ($st->fetchAll() as $c) $codigos[$c['pedido_detalle_id']][] = $c;

$hayFisico = (bool)$pedido['direccion_envio'];
$etapas = ['pagado' => 'Pagado', 'preparando' => 'Preparando', 'enviado' => 'Enviado', 'entregado' => 'Entregado'];
$actual = array_search($pedido['estado'], array_keys($etapas));

$titulo = 'Pedido ' . $pedido['folio'];
require 'includes/header.php';
?>
<div class="contenedor pagina pedido">
    <div class="pagina-cabecera">
        <?= letreroNeon(isset($_GET['nuevo']) ? '¡Gracias!' : 'Pedido', 'rosa') ?>
        <h1>Pedido <span data-descifrar><?= e($pedido['folio']) ?></span></h1>
        <?php if (!$esDueno): ?><p>Cliente: <b><?= e($pedido['cliente']) ?></b></p><?php endif; ?>
        <p><?= fechaLarga($pedido['creado']) ?> · <?= e(nombreMetodo($pedido['metodo_pago'])) ?></p>
    </div>

    <?php if ($pedido['estado'] === 'cancelado'): ?>
        <p class="alerta">Pedido cancelado el <?= fechaLarga($pedido['fecha_cancelacion']) ?>. Motivo: <?= e($pedido['motivo_cancelacion']) ?></p>
    <?php endif; ?>

    <?php if (puede('pedidos.cambiar_estado') && in_array($pedido['estado'], ['pagado', 'preparando', 'enviado'], true) || puede('pedidos.cancelar') && in_array($pedido['estado'], ['pagado', 'preparando'], true)): ?>
        <div class="acciones-personal">
            <b>Acciones del personal</b>
            <?php if ($hayFisico && puede('pedidos.cambiar_estado') && in_array($pedido['estado'], ['pagado', 'preparando', 'enviado'], true)): ?>
                <form data-api="pedidos/<?= $pedido['id'] ?>/estado" data-metodo="PATCH" data-confirmar="¿Pasar el pedido a la siguiente etapa del envío?">
                    <button class="btn btn-secundario" type="submit">Avanzar envío</button>
                </form>
            <?php endif; ?>
            <?php if (puede('pedidos.cancelar') && in_array($pedido['estado'], ['pagado', 'preparando'], true)): ?>
                <form data-api="pedidos/<?= $pedido['id'] ?>/cancelar" data-metodo="POST" data-confirmar="¿Seguro que quieres cancelar este pedido? Se regresará el inventario y se ajustarán los puntos." class="form-cancelar">
                    <label>Motivo<input type="text" name="motivo" maxlength="255" required placeholder="Ej. el cliente lo solicitó"></label>
                    <button class="btn btn-peligro" type="submit">Cancelar pedido</button>
                </form>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if ($hayFisico && $pedido['estado'] !== 'cancelado'): ?>
        <ol class="seguimiento" aria-label="Estado del envío">
            <?php $i = 0; foreach ($etapas as $clave => $nombre): ?>
                <li class="<?= $i <= $actual ? 'hecho' : '' ?> <?= $i === $actual ? 'actual' : '' ?>"><span></span><?= $nombre ?></li>
            <?php $i++; endforeach; ?>
        </ol>
        <div class="envio-demo">
            <?php if ($pedido['numero_guia']): ?><p>Número de guía: <b><?= e($pedido['numero_guia']) ?></b></p><?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if ($pedido['metodo_pago'] === 'oxxo'): ?>
        <div class="ficha-oxxo">
            <p>Referencia de pago OXXO</p>
            <b><?= referenciaOxxo($pedido['id']) ?></b>
            <small>Pago simulado: ya aparece como recibido.</small>
        </div>
    <?php endif; ?>

    <div class="compra-grid">
        <section class="lista-carrito">
            <?php foreach ($detalle as $d): ?>
                <article class="item-carrito">
                    <div class="item-arte">
                        <?= $d['juego_id'] ? portada(['id' => $d['juego_id'], 'titulo' => $d['titulo'], 'portada' => $d['portada']])
                                           : '<div class="portada tarjeta-psn-mini"><b>PSN</b><span>' . dinero($d['monto']) . '</span></div>' ?>
                    </div>
                    <div class="item-info">
                        <h3><?= $d['juego_id'] ? e($d['titulo']) : 'Tarjeta PSN ' . dinero($d['monto']) ?></h3>
                        <p><?= $d['cantidad'] ?> × <?= dinero($d['precio_unitario']) ?> · <?= $d['juego_id'] ? e(nombreEdicion($d)) : 'Saldo digital' ?></p>
                        <?php foreach ($codigos[$d['id']] ?? [] as $c): ?>
                            <div class="codigo <?= $c['activo'] ? '' : 'anulado' ?>">
                                <code data-descifrar><?= e($c['codigo']) ?></code>
                                <?php if ($c['activo']): ?><button type="button" class="btn-copiar" data-copiar="<?= e($c['codigo']) ?>">Copiar</button><?php else: ?><small>Anulado</small><?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <p class="item-precio"><strong><?= dinero($d['precio_unitario'] * $d['cantidad']) ?></strong></p>
                </article>
            <?php endforeach; ?>
            <?php if ($codigos): ?>
                <p class="ayuda-pago">Canjea tus códigos en tu PS5: <b>PlayStation Store → ··· → Canjear código</b>. (Códigos de demostración, no son reales).</p>
            <?php endif; ?>
        </section>

        <aside class="resumen">
            <h2>Resumen</h2>
            <dl>
                <dt>Subtotal</dt><dd><?= dinero($pedido['subtotal']) ?></dd>
                <?php if ($pedido['descuento_puntos'] > 0): ?><dt>Puntos</dt><dd>−<?= dinero($pedido['descuento_puntos']) ?></dd><?php endif; ?>
                <dt class="total">Total pagado</dt><dd class="total"><?= dinero($pedido['total']) ?> MXN</dd>
                <dt class="iva">IVA incluido (16%)</dt><dd class="iva"><?= dinero($pedido['iva']) ?></dd>
            </dl>
            <?php if ($pedido['puntos_ganados']): ?><p class="puntos-aviso">★ Ganaste <b><?= $pedido['puntos_ganados'] ?> puntos</b>. <?= $esDueno ? 'Ahora tienes ' . $u['puntos'] . '.' : '' ?></p><?php endif; ?>
            <?php if ($hayFisico): ?><p class="envio"><b>Envío a:</b><br><?= e($pedido['direccion_envio']) ?></p><?php endif; ?>
            <a class="btn btn-grande" href="catalogo.php">Seguir comprando</a>
            <a class="btn btn-grande btn-secundario" href="cuenta.php?s=pedidos">Ver mis pedidos</a>
        </aside>
    </div>
</div>
<?php if (isset($_GET['nuevo']) && $esDueno): ?>
<div class="aviso-escolar" role="dialog" aria-modal="true" aria-labelledby="aviso-escolar-titulo">
    <div class="aviso-escolar-caja">
        <img src="img/logo.svg" alt="" width="72" height="72">
        <?= letreroNeon('Aviso', 'rosa') ?>
        <h2 id="aviso-escolar-titulo">Esta no es una tienda real</h2>
        <p>Mala Fama Games es un <b>proyecto escolar</b> desarrollado por el equipo <b>Mala Fama Crew</b> del Instituto Tecnológico Superior de Irapuato (ITESI).</p>
        <p>Tu pedido <b><?= e($pedido['folio']) ?></b> se registró solo para demostrar el sistema: <b>no se hizo ningún cargo</b>, no se enviará ningún producto y <b>no se guardó ningún dato de tu tarjeta</b>. Los códigos son de demostración.</p>
        <p class="equipo">David Alejandro Sanchez Vital · Brandon Cristóbal Olivares · Alexis Antonio Mosqueda Vargas · Juan Pablo González Martínez</p>
        <div class="aviso-escolar-botones">
            <button type="button" class="btn" data-cerrar-aviso>Entendido, ver mi pedido</button>
        </div>
    </div>
</div>
<?php endif; ?>
<?php require 'includes/footer.php'; ?>

<?php
require_once 'includes/funciones.php';
$titulo = 'Aviso de Privacidad';
require 'includes/header.php';
?>
<article class="contenedor legal">
    <?= letreroNeon('Privacidad', 'morado') ?>
    <h1>Aviso de Privacidad</h1>
    <p class="legal-fecha">Última actualización: 28 de septiembre de 2026</p>
    <p class="legal-aviso">Proyecto escolar del equipo Mala Fama Crew (ITESI). Este aviso es un ejemplo con fines educativos.</p>

    <h2>¿Quién es responsable de tus datos?</h2>
    <p>Mala Fama Games (proyecto escolar de Mala Fama Crew, Irapuato, Guanajuato, México) es responsable del tratamiento de tus datos personales, conforme a la Ley Federal de Protección de Datos Personales en Posesión de los Particulares.</p>

    <h2>¿Qué datos recabamos?</h2>
    <ul>
        <li><b>Identificación y contacto:</b> nombre, correo electrónico y teléfono.</li>
        <li><b>Envío:</b> dirección de entrega de tus pedidos físicos.</li>
        <li><b>Compras:</b> productos que compras, códigos digitales entregados, puntos, lista de deseos y reseñas.</li>
        <li><b>Acceso:</b> tu contraseña, que guardamos cifrada; nadie, ni nosotros, puede verla.</li>
    </ul>
    <p><b>No guardamos los datos de tu tarjeta.</b> Los pagos los procesan directamente las pasarelas (tarjeta, PayPal, Mercado Pago u OXXO Pay). Tampoco recabamos datos personales sensibles.</p>

    <h2>¿Para qué los usamos?</h2>
    <p><b>Finalidades necesarias:</b> crear y administrar tu cuenta, procesar y enviar tus pedidos, entregarte tus códigos digitales, administrar tus puntos, darte atención y cumplir obligaciones legales.</p>
    <p><b>Finalidades secundarias:</b> avisarte de ofertas o de que un juego de tu lista de deseos bajó de precio. Si no quieres esto, puedes pedirlo en cualquier momento sin que afecte tus compras.</p>

    <h2>¿Con quién los compartimos?</h2>
    <p>Solo con quien es necesario para completar tu compra: la pasarela de pago que elijas y la paquetería que entrega tus juegos físicos. No vendemos ni rentamos tus datos.</p>

    <h2>Tus derechos ARCO</h2>
    <p>Puedes <b>Acceder</b> a tus datos, <b>Rectificarlos</b> si están mal, <b>Cancelarlos</b> y <b>Oponerte</b> a su uso, además de revocar tu consentimiento. Muchos datos los puedes corregir tú mismo en <a href="cuenta.php?s=perfil">Mis datos</a>. Para cualquier otra solicitud escríbenos indicando tu nombre, correo de la cuenta y lo que necesitas; te respondemos en un máximo de 20 días hábiles.</p>

    <h2>Cookies</h2>
    <p>Usamos una cookie de sesión para mantenerte con tu sesión iniciada y guardar tu carrito mientras navegas. No usamos cookies de publicidad ni de rastreo de terceros.</p>

    <h2>Seguridad</h2>
    <p>El sitio usa conexión cifrada (HTTPS), las contraseñas se guardan cifradas y los formularios están protegidos contra envíos falsos.</p>

    <h2>Cambios a este aviso</h2>
    <p>Cualquier cambio lo publicaremos en esta misma página, con su fecha de actualización.</p>
</article>
<?php require 'includes/footer.php'; ?>

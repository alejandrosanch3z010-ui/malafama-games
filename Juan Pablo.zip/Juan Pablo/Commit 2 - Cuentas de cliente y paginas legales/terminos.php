<?php
require_once 'includes/funciones.php';
$titulo = 'Términos y Condiciones';
require 'includes/header.php';
?>
<article class="contenedor legal">
    <?= letreroNeon('Términos', 'cian') ?>
    <h1>Términos y Condiciones</h1>
    <p class="legal-fecha">Última actualización: 28 de septiembre de 2026</p>
    <p class="legal-aviso">Mala Fama Games es un proyecto escolar del equipo Mala Fama Crew (ITESI). No es una tienda real: los pagos son simulados y no se cobra ni se envía ningún producto.</p>

    <nav class="legal-indice" aria-label="Contenido">
        <a href="#uso">1. Uso del sitio</a><a href="#cuenta">2. Tu cuenta</a><a href="#precios">3. Precios y pagos</a>
        <a href="#preventas">4. Preventas</a><a href="#envios">5. Envíos</a><a href="#digitales">6. Productos digitales</a>
        <a href="#puntos">7. Programa de puntos</a><a href="#resenas">8. Reseñas</a><a href="#marcas">9. Marcas</a><a href="#ley">10. Ley aplicable</a>
    </nav>

    <h2 id="uso">1. Uso del sitio</h2>
    <p>Al navegar o comprar en Mala Fama Games aceptas estos Términos. Si no estás de acuerdo con ellos, por favor no uses el sitio. Podemos actualizarlos en cualquier momento; la versión vigente es la que aparece en esta página.</p>

    <h2 id="cuenta">2. Tu cuenta</h2>
    <p>Para comprar, guardar juegos en tu lista de deseos o dejar reseñas necesitas una cuenta. Eres responsable de mantener tu contraseña en secreto y de la actividad que ocurra en tu cuenta. Debes ser mayor de edad o contar con permiso de tu madre, padre o tutor para comprar.</p>

    <h2 id="precios">3. Precios y pagos</h2>
    <p>Los precios están en pesos mexicanos (MXN) e incluyen impuestos. Aceptamos tarjeta de crédito o débito, PayPal, Mercado Pago y OXXO Pay. Un pedido se confirma cuando el pago es aprobado. Si detectamos un error evidente en un precio, podemos cancelar el pedido y reembolsar lo pagado.</p>
    <p>No guardamos los datos de tu tarjeta: el pago lo procesa directamente la pasarela que elijas.</p>

    <h2 id="preventas">4. Preventas</h2>
    <p>Al apartar un juego en preventa pagas su precio completo. La fecha de lanzamiento la define la editorial y puede cambiar; si se retrasa, te avisaremos y podrás cancelar tu preventa con reembolso total antes de que el juego salga a la venta.</p>

    <h2 id="envios">5. Envíos</h2>
    <p>Los juegos físicos se envían a la dirección que indiques en el pago, dentro de México. El envío es gratis. Puedes seguir el estado de tu pedido (Pagado, Preparando, Enviado y Entregado) en <a href="cuenta.php?s=pedidos">Mis pedidos</a>, donde también verás el número de guía cuando el paquete salga.</p>

    <h2 id="digitales">6. Productos digitales</h2>
    <p>Los juegos digitales y las tarjetas PSN se entregan como un código que aparece en tu pedido y en <a href="cuenta.php?s=codigos">Mis códigos</a> en cuanto se aprueba el pago. Los códigos se canjean en la PlayStation Store con tu cuenta de PlayStation Network. Consulta la <a href="devoluciones.php">Política de Devoluciones</a> para saber cuándo aplica un reembolso.</p>

    <h2 id="puntos">7. Programa de puntos</h2>
    <p>Por cada juego que compras ganas el <?= PUNTOS_POR_PESO * 100 ?>% de su precio en puntos. Cada punto vale <?= dinero(VALOR_PUNTO) ?> y puedes usarlos para pagar hasta la mitad de una compra. Los puntos no son dinero, no se pueden cambiar por efectivo ni transferir a otra cuenta. Si un pedido se cancela o se reembolsa, se descuentan los puntos que generó.</p>

    <h2 id="resenas">8. Reseñas y opiniones</h2>
    <p>Puedes calificar juegos y la tienda. No publiques contenido ofensivo, datos personales de otras personas ni publicidad. Podemos retirar reseñas que no cumplan estas reglas.</p>

    <h2 id="marcas">9. Marcas y contenido</h2>
    <p>PlayStation, PS5 y PlayStation Network son marcas de Sony Interactive Entertainment. Los nombres, portadas y tráileres de los juegos pertenecen a sus respectivos dueños y se usan solo con fines educativos.</p>

    <h2 id="ley">10. Ley aplicable</h2>
    <p>Estos Términos se rigen por las leyes de los Estados Unidos Mexicanos, incluida la Ley Federal de Protección al Consumidor. Si tienes una queja, escríbenos primero para resolverla; también puedes acudir a la Procuraduría Federal del Consumidor (Profeco).</p>
</article>
<?php require 'includes/footer.php'; ?>
